<footer class="footer-box footer-10">
    <div class="footer-bottom">
        <div class="container clearfix">
            <div class="row row-display-table text-center home01-lh">
                <div class="left">
                    <!-- Copyright -->
                    <p> Copyright 2018 by Mystartupleads.com<span class="sep">|</span><a href="#" title="Terms of Use">Privacy Statement</a><span class="sep">|</span><a href="#" title="Terms of Use">Terms of Use</a></p>
                    <!-- Copyright End -->
                </div>
                <!-- Subscribe -->
                <!-- Social -->
                <div class="right">
                    <div class="footer-social07 footer-social07-home01"> <a href="#" title="facebook"><span class="fa fa-facebook color-white"></span></a> <a href="#" title="twitter"><span class="fa fa-twitter color-white"></span></a> <a href="#" title="linkedin"><span class="fa fa-vimeo color-white"></span></a>
                        <a href="#" title="pinterest"><span class="fa fa-google-plus color-white"></span></a></div>
                </div>
                <!-- Social End -->
                <!-- Subscribe End -->
            </div>
        </div>
    </div>
</footer>
<div id="to-top" class="backtop01"><span></span></div>
</div>
</div>
<script src="<?php echo base_url()  ?>site_asset/vendor/bootstrap/js/bootstrap.min.js"></script>
<!-- CircleSlider -->
<script src="<?php echo base_url()  ?>site_asset/vendor/circle.slider/jquery.content_slider.min.js"></script>
<!-- isotope -->
<script src="<?php echo base_url()  ?>site_asset/vendor/isotope/isotope.pkgd.min.js"></script>
<!-- OwlCarousel -->
<script src="<?php echo base_url()  ?>site_asset/vendor/OwlCarousel2/owl.carousel.min.js"></script>
<!--custom-->
<script src="<?php echo base_url()  ?>site_asset/js/theme-functions.js"></script>
<script src="<?php echo base_url()  ?>site_asset/js/custom.js"></script>
</body>
</html>