<?php

if($this->session->flashdata('msg')=="success")
{
    ?>
    <script>

        alert('Your Message is submitted Successfully');

    </script>

    <?php
}
?>



<div id="rev_slider_4_1_wrapper" class="rev_slider_wrapper fullscreen-container" data-alias="particle-effect-one5"
     data-source="gallery" style="background:#eef0f1;padding:0px;">
    <!-- START REVOLUTION SLIDER 5.4.1 fullscreen mode -->
    <div id="rev_slider_4_1" class="rev_slider fullscreenbanner" style="display:none;" data-version="5.4.1">
        <ul>
            <!-- SLIDE  -->
            <li data-index="rs-10" data-transition="fade" data-slotamount="default" data-hideafterloop="0"
                data-hideslideonmobile="off" data-easein="Power4.easeOut" data-easeout="Power4.easeOut"
                data-masterspeed="default" data-thumb="http://works.themepunch.com/revolution_5_3/wp-content/"
                data-rotate="0" data-saveperformance="off" data-title="Example One" data-param1="" data-param2=""
                data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9=""
                data-param10="" data-description="">
                <!-- MAIN IMAGE -->
                <img src="#" data-bgcolor='#ffffff' style='background:#ffffff' alt="" data-bgposition="center center"
                     data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
                <!-- LAYERS -->

                <!-- LAYER NR. 1 -->
                <div class="tp-caption  "
                     id="slide-10-layer-4"
                     data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                     data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']"
                     data-width="full-proportional"
                     data-height="full-proportional"
                     data-whitespace="nowrap"

                     data-type="image"
                     data-basealign="slide"
                     data-responsive_offset="off"
                     data-wrapper_class="tp-nopointer"
                     data-responsive="off"
                     data-frames='[{"delay":600,"speed":1500,"frame":"0","from":"sX:1;sY:1;opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":1500,"frame":"999","to":"opacity:0;","ease":"Power4.easeOut"}]'
                     data-textAlign="['inherit','inherit','inherit','inherit']"
                     data-paddingtop="[0,0,0,0]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0]"
                     data-paddingleft="[0,0,0,0]"
                     data-blendmode="screen"

                     style="z-index: 5;"><img
                            src="<?php echo base_url() ?>site_asset/inset/homepage01/home01-banner1.jpg" alt=""
                            data-ww="['full-proportional','full-proportional','full-proportional','full-proportional']"
                            data-hh="['full-proportional','full-proportional','full-proportional','full-proportional']"
                            width="1920" height="1281" data-no-retina></div>

                <!-- LAYER NR. 2 -->
                <div class="tp-caption   tp-resizeme"
                     id="slide-10-layer-6"
                     data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                     data-y="['middle','middle','middle','middle']" data-voffset="['-70','-100','-100','-100']"
                     data-width="none"
                     data-height="none"
                     data-whitespace="nowrap"

                     data-type="text"
                     data-responsive_offset="on"
                     data-wrapper_class="tp-nopointer"

                     data-frames='[{"delay":500,"split":"chars","splitdelay":0.1,"speed":300,"frame":"0","from":"y:[-100%];sX:1;sY:2;opacity:0;fb:10px;","to":"o:1;fb:0;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;fb:0;","ease":"Power3.easeInOut"}]'
                     data-textAlign="['inherit','inherit','inherit','inherit']"
                     data-paddingtop="[0,0,0,0]"
                     data-paddingright="[20,20,20,20]"
                     data-paddingbottom="[0,0,0,0]"
                     data-paddingleft="[20,20,20,20]"

                     style="z-index: 6; white-space: nowrap; font-size: 70px; line-height: 70px; font-weight: 900; color: rgba(45,48,50,1);font-family:Raleway;">
                    Exclusive Business Leads only INR 400 / week
                </div>

                <!-- LAYER NR. 3 -->
                <div class="tp-caption   tp-resizeme"
                     id="slide-10-layer-8"
                     data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                     data-y="['middle','middle','middle','middle']" data-voffset="['0','-30','-20','-20']"
                     data-width="['none','none','361','330']"
                     data-height="none"
                     data-whitespace="['nowrap','nowrap','normal','normal']"

                     data-type="text"
                     data-responsive="on"
                     data-responsive_offset="on"
                     data-wrapper_class="tp-nopointer"

                     data-frames='[{"delay":600,"speed":1000,"frame":"0","from":"y:-20px;sX:1;sY:1;opacity:0;fb:10px;","to":"o:1;fb:0;","ease":"Power4.easeOut"},{"delay":"wait","speed":600,"frame":"999","to":"auto:auto;fb:0;","ease":"Power3.easeInOut"}]'
                     data-textAlign="['inherit','inherit','center','center']"
                     data-paddingtop="[0,0,0,0]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0]"
                     data-paddingleft="[0,0,0,0]"

                     style="z-index: 7; white-space: nowrap; font-size: 17px; line-height: 25px; font-weight: 700; color: #333;font-family:Raleway;letter-spacing:10px;">
                    DOWNLOAD DATA, CONNECT TO LEADS AND TURN THEM INTO CUSTOMERS.
                </div>

                <!-- LAYER NR. 4 -->
                <a href="<?php echo base_url() ?>payment/make_order/1" class="tp-caption rev-btn  tp-resizeme" href="#"
                   target="_blank" id="slide-10-layer-10"
                   data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                   data-y="['middle','middle','middle','middle']" data-voffset="['70','40','60','60']"
                   data-width="none"
                   data-height="none"
                   data-whitespace="nowrap"

                   data-type="button"
                   data-actions=''
                   data-responsive="on"
                   data-responsive_offset="on"

                   data-frames='[{"delay":1000,"speed":1000,"frame":"0","from":"y:-20px;opacity:0;fb:10px;","to":"o:1;fb:0;","ease":"Power4.easeOut"},{"delay":"wait","speed":600,"frame":"999","to":"auto:auto;fb:0;","ease":"Power3.easeInOut"},{"frame":"hover","speed":"200","ease":"Linear.easeNone","to":"o:1;rX:0;rY:0;rZ:0;z:0;fb:0;","style":"c:rgba(255,255,255,1);bg:rgba(45,48,50,1);bs:solid;bw:0 0 0 0;"}]'
                   data-textAlign="['inherit','inherit','inherit','inherit']"
                   data-paddingtop="[0,0,0,0]"
                   data-paddingright="[35,35,35,35]"
                   data-paddingbottom="[0,0,0,0]"
                   data-paddingleft="[35,35,35,35]"
                   style="z-index: 8; white-space: nowrap; font-size: 15px; line-height: 50px;border-radius:25px; font-weight: 700; color: rgba(255,255,255,1);font-family:Raleway;background-color:#20a3f0;border-color:rgba(0,0,0,1);outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;text-decoration: none;">Pay
                    Rs 400 For a week
                </a></li>
            <!-- SLIDE  -->
            <li data-index="rs-11" data-transition="fade" data-slotamount="default" data-hideafterloop="0"
                data-hideslideonmobile="off" data-easein="Power4.easeOut" data-easeout="Power4.easeOut"
                data-masterspeed="default" data-thumb="http://works.themepunch.com/revolution_5_3/wp-content/"
                data-rotate="0" data-saveperformance="off" data-title="Example Two" data-param1="" data-param2=""
                data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9=""
                data-param10="" data-description="">
                <!-- MAIN IMAGE -->
                <img src="<?php echo base_url() ?>site_asset/vendor/revolution-plugin/assets/images/transparent.png"
                     data-bgcolor='#ffffff' style='background:#ffffff' alt="" data-bgposition="center center"
                     data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
                <!-- LAYERS -->

                <!-- LAYER NR. 5 -->
                <div class="tp-caption  "
                     id="slide-11-layer-4"
                     data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                     data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']"
                     data-width="full-proportional"
                     data-height="full-proportional"
                     data-whitespace="nowrap"

                     data-type="image"
                     data-basealign="slide"
                     data-responsive_offset="off"
                     data-wrapper_class="tp-nopointer"
                     data-responsive="off"
                     data-frames='[{"delay":600,"speed":1500,"frame":"0","from":"sX:1;sY:1;opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":1500,"frame":"999","to":"opacity:0;","ease":"Power4.easeOut"}]'
                     data-textAlign="['inherit','inherit','inherit','inherit']"
                     data-paddingtop="[0,0,0,0]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0]"
                     data-paddingleft="[0,0,0,0]"
                     data-blendmode="screen"

                     style="z-index: 5;"><img
                            src="<?php echo base_url() ?>site_asset/inset/homepage01/home01-banner2.jpg" alt=""
                            data-ww="['full-proportional','full-proportional','full-proportional','full-proportional']"
                            data-hh="['full-proportional','full-proportional','full-proportional','full-proportional']"
                            width="1920" height="1280" data-no-retina></div>

                <!-- LAYER NR. 6 -->

                <div class="tp-caption  "
                     id="slide-12-layer-4"
                     data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                     data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']"
                     data-width="full-proportional"
                     data-height="full-proportional"
                     data-whitespace="nowrap"

                     data-type="image"
                     data-basealign="slide"
                     data-responsive_offset="off"
                     data-wrapper_class="tp-nopointer"
                     data-responsive="off"
                     data-frames='[{"delay":600,"speed":1500,"frame":"0","from":"sX:1;sY:1;opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":1500,"frame":"999","to":"opacity:0;","ease":"Power4.easeOut"}]'
                     data-textAlign="['inherit','inherit','inherit','inherit']"
                     data-paddingtop="[0,0,0,0]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0]"
                     data-paddingleft="[0,0,0,0]"
                     data-blendmode="screen"

                     style="z-index: 5;"><img
                            src="<?php echo base_url() ?>site_asset/inset/homepage01/home01-banner3.jpg" alt=""
                            data-ww="['full-proportional','full-proportional','full-proportional','full-proportional']"
                            data-hh="['full-proportional','full-proportional','full-proportional','full-proportional']"
                            width="1920" height="1281" data-no-retina></div>

                <!-- LAYER NR. 10 -->
                <div class="tp-caption   tp-resizeme"
                     id="slide-12-layer-6"
                     data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                     data-y="['middle','middle','middle','middle']" data-voffset="['-70','-100','-100','-100']"
                     data-width="none"
                     data-height="none"
                     data-whitespace="nowrap"

                     data-type="text"
                     data-responsive="on"
                     data-responsive_offset="on"
                     data-wrapper_class="tp-nopointer"

                     data-frames='[{"delay":500,"split":"chars","splitdelay":0.1,"speed":300,"frame":"0","from":"y:[-100%];sX:1;sY:2;opacity:0.2;fb:10px;","to":"o:1;fb:0;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;fb:0;","ease":"Power3.easeInOut"}]'
                     data-textAlign="['inherit','inherit','inherit','inherit']"
                     data-paddingtop="[0,0,0,0]"
                     data-paddingright="[20,20,20,20]"
                     data-paddingbottom="[0,0,0,0]"
                     data-paddingleft="[20,20,20,20]"
                     data-blendmode="exclusion"

                     style="z-index: 6; white-space: nowrap; font-size: 80px; line-height: 80px; font-weight: 900; color: rgba(255,255,255,0.85);font-family:Raleway;">
                    Best & Filtered Leads
                </div>

                <!-- LAYER NR. 11 -->
                <div class="tp-caption   tp-resizeme"
                     id="slide-12-layer-8"
                     data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                     data-y="['middle','middle','middle','middle']" data-voffset="['0','-30','-20','-20']"
                     data-width="['none','none','361','330']"
                     data-height="none"
                     data-whitespace="['nowrap','nowrap','normal','normal']"

                     data-type="text"
                     data-responsive="on"
                     data-responsive_offset="on"
                     data-wrapper_class="tp-nopointer"

                     data-frames='[{"delay":600,"speed":1000,"frame":"0","from":"y:-20px;sX:1;sY:1;opacity:0;fb:10px;","to":"o:1;fb:0;","ease":"Power4.easeOut"},{"delay":"wait","speed":600,"frame":"999","to":"auto:auto;fb:0;","ease":"Power3.easeInOut"}]'
                     data-textAlign="['inherit','inherit','center','center']"
                     data-paddingtop="[0,0,0,0]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0]"
                     data-paddingleft="[0,0,0,0]"
                     data-blendmode="exclusion"

                     style="z-index: 7; white-space: nowrap; font-size: 17px; line-height: 25px; font-weight: 700; color: rgba(255,255,255,0.85);font-family:Raleway;letter-spacing:10px;">
                    START & RISE WITH YOUR BUSINESS
                </div>

                <!-- LAYER NR. 12 -->
                <a href="<?php echo base_url() ?>payment/make_order/3" class="tp-caption rev-btn  tp-resizeme" href="#"
                   target="_blank" id="slide-10-layer-10"
                   data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                   data-y="['middle','middle','middle','middle']" data-voffset="['70','40','60','60']"
                   data-width="none"
                   data-height="none"
                   data-whitespace="nowrap"

                   data-type="button"
                   data-actions=''
                   data-responsive="on"
                   data-responsive_offset="on"

                   data-frames='[{"delay":1000,"speed":1000,"frame":"0","from":"y:-20px;opacity:0;fb:10px;","to":"o:1;fb:0;","ease":"Power4.easeOut"},{"delay":"wait","speed":600,"frame":"999","to":"auto:auto;fb:0;","ease":"Power3.easeInOut"},{"frame":"hover","speed":"200","ease":"Linear.easeNone","to":"o:1;rX:0;rY:0;rZ:0;z:0;fb:0;","style":"c:rgba(255,255,255,1);bg:rgba(45,48,50,1);bs:solid;bw:0 0 0 0;"}]'
                   data-textAlign="['inherit','inherit','inherit','inherit']"
                   data-paddingtop="[0,0,0,0]"
                   data-paddingright="[35,35,35,35]"
                   data-paddingbottom="[0,0,0,0]"
                   data-paddingleft="[35,35,35,35]"

                   style="z-index: 8; white-space: nowrap; font-size: 15px; line-height: 50px; border-radius:25px;font-weight: 700; color: rgba(255,255,255,1);font-family:Raleway;background-color:#20a3f0;border-color:rgba(0,0,0,1);outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;text-decoration: none;">Pay
                    Rs 3999 for 3 months </a></li>
        </ul>
        <div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>
    </div>
</div>

<script type="text/javascript">
    var tpj = jQuery;

    var revapi4;
    tpj(document).ready(function () {
        if (tpj("#rev_slider_4_1").revolution == undefined) {
            revslider_showDoubleJqueryError("#rev_slider_4_1");
        } else {
            revapi4 = tpj("#rev_slider_4_1").show().revolution({
                sliderType: "standard",
                jsFileLocation: "revolution/js/",
                sliderLayout: "fullscreen",
                dottedOverlay: "none",
                delay: 9000,
                particles: {
                    startSlide: "first", endSlide: "last", zIndex: "1",
                    particles: {
                        number: {value: 80}, color: {value: "#000000"},
                        shape: {
                            type: "circle", stroke: {width: 0, color: "#ffffff", opacity: 1},
                            image: {src: ""}
                        },
                        opacity: {
                            value: 0.3,
                            random: false,
                            min: 0.25,
                            anim: {enable: false, speed: 3, opacity_min: 0, sync: false}
                        },
                        size: {
                            value: 10,
                            random: true,
                            min: 1,
                            anim: {enable: false, speed: 40, size_min: 1, sync: false}
                        },
                        line_linked: {enable: true, distance: 200, color: "#000000", opacity: 0.2, width: 1},
                        move: {
                            enable: true,
                            speed: 3,
                            direction: "none",
                            random: true,
                            min_speed: 3,
                            straight: false,
                            out_mode: "out"
                        }
                    },
                    interactivity: {
                        events: {onhover: {enable: true, mode: "bubble"}, onclick: {enable: false, mode: "repulse"}},
                        modes: {
                            grab: {distance: 400, line_linked: {opacity: 0.5}},
                            bubble: {distance: 400, size: 150, opacity: 1},
                            repulse: {distance: 200}
                        }
                    }
                },
                navigation: {
                    keyboardNavigation: "off",
                    keyboard_direction: "horizontal",
                    mouseScrollNavigation: "off",
                    mouseScrollReverse: "default",
                    onHoverStop: "off",
                    arrows: {
                        style: "gyges",
                        enable: true,
                        hide_onmobile: false,
                        hide_onleave: false,
                        tmp: '',
                        left: {
                            h_align: "center",
                            v_align: "bottom",
                            h_offset: -20,
                            v_offset: 0
                        },
                        right: {
                            h_align: "center",
                            v_align: "bottom",
                            h_offset: 20,
                            v_offset: 0
                        }
                    }
                },
                responsiveLevels: [1240, 1024, 778, 480],
                visibilityLevels: [1240, 1024, 778, 480],
                gridwidth: [1240, 1024, 778, 480],
                gridheight: [868, 768, 960, 720],
                lazyType: "none",
                shadow: 0,
                spinner: "off",
                stopLoop: "on",
                stopAfterLoops: 0,
                stopAtSlide: 1,
                shuffle: "off",
                autoHeight: "off",
                fullScreenAutoWidth: "off",
                fullScreenAlignForce: "off",
                fullScreenOffsetContainer: "",
                fullScreenOffset: "60px",
                disableProgressBar: "on",
                hideThumbsOnMobile: "off",
                hideSliderAtLimit: 0,
                hideCaptionAtLimit: 0,
                hideAllCaptionAtLilmit: 0,
                debugMode: false,
                fallbacks: {
                    simplifyAll: "off",
                    nextSlideOnWindowFocus: "off",
                    disableFocusListener: false,
                }
            });
        }

        RsParticlesAddOn(revapi4);
    });
    /*ready*/
</script>

<section id="page-content">


    <div class="home01-bg11 pt-50 pb-50">
        <div class="container pt-80 pb-80">
            <div class="home01-cont3">
                <h4 class="title">Why Us</h4>
                <div class="description">We provide filtered , 100% authenticate contacts to our clients. Connect to
                    your leads , show your skill to convert them into your clients. Its a mega opportunity for all
                    Start-Ups to explore the world
                </div>

            </div>
        </div>
    </div>


    <div class="container pt-60">
        <!--Our Pricing-->
        <div class="dg-title07 text-center">
            <h2 class="title">OUR PRICING</h2>
            <small>Powerful Options</small>
        </div>
        <div class="dg-price01 row pt-10">

            <?php foreach ($all_message as $value) { ?>
                <div class="col-md-4 col-sm-6">
                    <div class="price-border">
                        <div class="price-title"><span class="fa fa-satellite"></span>
                            <h2><?php echo $value->product_title ?></h2>
                        </div>
                        <div class="price-box"><span class="sup">$</span><span
                                    class="price">INR <?php echo $value->price_inr ?></span><span class="unit"></span>
                            <p><?php echo $value->summary ?></p>
                        </div>
                        <div class="price-holder">
                            <ul>
                                <li><h3>Duration <?php echo $value->duration ?> Days</h3></li>

                                <li class="star-list"><span class="fa fa-star"></span><span
                                            class="fa fa-star"></span><span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star-o"></span>
                                </li>
                            </ul>
                        </div>
                        <div class="footer">
                            <a title="BUY IT NOW!"
                               class=" dg-btn-1 hover-accent radius-3px"
                               href="<?php echo base_url() ?>payment/make_order/<?php echo $value->id ?>"
                               target="_blank">BUY IT NOW!
                            </a></div>
                    </div>
                </div>
            <?php } ?>
        </div>
        <!--Our Pricing End-->
    </div>


    <div class="home01-bg16 pt-80 pb-80">
        <div class="container ">
            <div class="dg-title42 text-center"> FEATURE <span class="color-accent">LISTS</span></div>
            <p class="pb-30 width-60 text-center">We provide leads for following sectors</p>
            <div class="row">
                <div class="col-sm-6 col-md-3">
                    <ul class="list-ico">
                        <li><em class="fa fa-checkmark-circle"></em> Daily Upload Before 8AM IST</li>
                        <li><em class="fa fa-checkmark-circle"></em> Global Whois Data</li>
                        <li><em class="fa fa-checkmark-circle"></em> 5M+ Newly Registered Domains</li>
                        <li><em class="fa fa-checkmark-circle"></em> Historic Whois Database</li>

                    </ul>
                </div>
                <div class="col-sm-6 col-md-3">
                    <ul class="list-ico">
                        <li><em class="fa fa-checkmark-circle"></em> Unlimited Access</li>
                        <li><em class="fa fa-checkmark-circle"></em> Accurate Data</li>
                        <li><em class="fa fa-checkmark-circle"></em> CountryWise Filtered files</li>
                        <li><em class="fa fa-checkmark-circle"></em> Registrar Specific</li>

                    </ul>
                </div>
                <div class="col-sm-6 col-md-3">
                    <ul class="list-ico">
                        <li><em class="fa fa-checkmark-circle"></em> Best Price All over World</li>
                        <li><em class="fa fa-checkmark-circle"></em> Instant Account Activation</li>
                        <li><em class="fa fa-checkmark-circle"></em> Removal of Whois Privacy / Proxies</li>
                        <li><em class="fa fa-checkmark-circle"></em> all major TLDs like .COM, .NET, .ORG</li>

                    </ul>
                </div>
                <div class="col-sm-6 col-md-3">
                    <ul class="list-ico">
                        <li><em class="fa fa-checkmark-circle"></em> Downloaded in Excel Format</li>
                        <li><em class="fa fa-checkmark-circle"></em> Our Team Page</li>
                        <li><em class="fa fa-checkmark-circle"></em> Clean list of real ownership data</li>
                        <li><em class="fa fa-checkmark-circle"></em> 24*7 online support</li>

                    </ul>
                </div>
            </div>

        </div>
    </div>


    <div class="container pt-60 pb-60">
        <div class="dg-title03 text-center pb-20">
            <h3>Latest News</h3>
            <div class="line"><i class="fa fa-news"></i></div>
        </div>
        <style>
            A:hover {
                color: #20a3f0;
                text-decoration: none!important;
            }

        </style>
        <div class="row">
            <?php
            //                var_dump($all_blog);
            //                die();
            $i = 1;
            foreach ($all_blog as $blog) {
                $i++;
                ?>
                <div class="col-md-4">
                    <a href="<?php echo base_url() ?>blog/detail/<?php echo $blog->blog_slug; ?>">
                        <div class="home02-imglist"><img alt="We create Exclusive Brands"
                                                         class="img-responsive text-center"
                                                         style="padding-bottom : 15px; height: 198px;; width: 362px;"
                                                         src="<?php echo base_url() ?>/uploads/blogs/<?php echo $blog->blog_image ?>">
                            <h4><?php echo $blog->blog_title; ?></h4>

                            <span class="time" style="color: black"><?php
                                $dateall = $blog->created_at;
                                $d = date("d", strtotime($dateall));
                                $m = date("m", strtotime($dateall));
                                $y = date("yy", strtotime($dateall));
                                $monthNum = $m;
                                $monthName = date("F", mktime(0, 0, 0, $monthNum, 10));
                                $shortmonthname = substr($monthName, 0, 3);
                                echo  "Publised at : ".$d ."-". $shortmonthname ."-".$y;
                                ?></span>
<hr>
                            <p style="color: black"><?php echo $blog->blog_summary; ?></p>
                            <div class="home02-imginfo" style="font-weight: 600;"><span
                                        style="color: black">Author : </span><?php echo $blog->added_by ?> </div>
                        </div>
                    </a>
                </div>
            <?php } ?>


        </div>
    </div>

    <div class="home02-bg03 pt-80 pb-80 color-white"
         style="background-image: url(<?php echo base_url() ?>site_asset/inset/homepage02/home02-bg03.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="dg-title03  color-white text-center pb-30">
                        <small>We also provides custome leads for our clients.
                            We provides leads for mostly all kinf of business.
                            Custom leads are provided on the basis of keywords
                            such as "hotels", "Plumbers", etc
                        </small>
                       <h3>Contact Us</h3>
                        <div class="line color-white"><i class="fa fa-phone-in-out"></i></div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="home02-contact mt-20">
                        <h4>Contact Details</h4>
                        <div class="mt-20 mb-20">
                        </div>
                        <ul class="info-list">
                            <li><i class="fa fa-skype"></i>&nbsp;&nbsp; mystartupleads@gmail.com</li>
                            <li><i class="fa fa-phone-wave"></i>&nbsp;&nbsp; INDIA +91-9673879759</li>
                            <li><i class="fa fa-envelope-open2"></i>&nbsp;&nbsp;mystartupleads@gmail.com.</li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-6">
                    <form method="post" action="<?php echo base_url()?>contact/send_contact">
                        <div class="row dg-form-content02">
                            <div class="col-sm-6">
                                <div class="form-row">
                                    <input id="Name" type="text" name="custname" class="flvname" required="">
                                    <label>Name*</label>
                                    <span class="line"></span></div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-row">
                                    <input id="Email" type="email" name="email" class="flvname" required="">
                                    <label>Email*</label>
                                    <span class="line"></span></div>
                            </div>

                            <div class="col-sm-6">
                                <div class="form-row">
                                    <input id="phone" type="text" name="phone" class="flvname" required="">
                                    <label>Phone*</label>
                                    <span class="line"></span></div>
                            </div>

                            <div class="col-sm-12">
                                <div class="form-row">
                                    <input id="text" type="text" name="subject" class="flvname" required="">
                                    <label>Subject*</label>
                                    <span class="line"></span></div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-row">
                                    <textarea id="mymessage" name="message" class="flvmessage" rows="5"
                                              required=""></textarea>
                                    <label>Message*</label>
                                    <span class="line"></span></div>
                            </div>
                            <div class="col-sm-12 text-right mt-20">
                                <input type="submit"  title="SEND" value="SEND NOW"
                                       class="dg-btn-1 btn-accent ">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


</section>
