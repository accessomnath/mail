

<!-- Container -->
<div class="container padding-bottom">

    <!-- Help Search -->

    <div class="row padding-top">

        <!-- Content -->
        <div class="col-lg-8 col-md-8 col-lg-offset-1 col-lg-push-3 col-md-push-4">
            <h2 class="block-title">
               SemiColon IT & Software Pvt <Ltd class=""></Ltd>
                <small>Know More about us</small>
            </h2>
            <img src="<?php echo base_url() ?>site_asset/img/innovation.jpg" class="space-bottom" alt="Image">
            <p class="padding-bottom">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum.</p>
            <div class="panel-group" id="accordion">
                <div class="panel">
                    <div class="panel-heading">
                        <a class="panel-title collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                            1st Step : Requirement Analysis
                        </a>
                    </div>
                    <div id="collapseOne" class="panel-collapse collapse">
                        <div class="panel-body">
                            <div class="col-md-8">
                            Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo.
                            </div>
                            
                            <div class="col-md-4">
                                
                                <img src="<?php echo base_url() ?>/site_asset/img/requirement.jpg">
                                
                            </div>
                        </div>
                    </div>
                </div><!-- .panel -->
                <div class="panel">
                    <div class="panel-heading">
                        <a class="panel-title collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                            2nd Step : Designing Phase
                        </a>
                    </div>
                    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel">
                        <div class="panel-body">

                            <div class="col-md-4">

                                <img src="<?php echo base_url() ?>/site_asset/img/responsive-web-design.png">

                            </div>
                            <div class="col-md-8">
                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo.
                            </div>


                        </div>
                    </div>
                </div><!-- .panel -->
                <div class="panel">
                    <div class="panel-heading">
                        <a class="panel-title" data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
                           3rd Phase: Development Phase
                        </a>
                    </div>
                    <div id="collapseThree" class="panel-collapse collapse in">
                        <div class="panel-body">
                            <div class="col-md-8">
                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo.
                            </div>

                            <div class="col-md-4">

                                <img src="<?php echo base_url() ?>/site_asset/img/web-development.png">

                            </div>
                        </div>
                    </div>
                </div><!-- .panel -->
                <div class="panel">
                    <div class="panel-heading">
                        <a class="panel-title collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFour">
                            4th Phase: Development & Testing Phase
                        </a>
                    </div>
                    <div id="collapseFour" class="panel-collapse collapse">
                        <div class="panel-body">
                            <div class="col-md-4">

                                <img src="<?php echo base_url() ?>/site_asset/img/software-testing.png">

                            </div>
                            <div class="col-md-8">
                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo.
                            </div>
                        </div>
                    </div>
                </div><!-- .panel -->

                <div class="panel">
                    <div class="panel-heading">
                        <a class="panel-title collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFive">
                            5th Phase: Deployment Phase
                        </a>
                    </div>
                    <div id="collapseFive" class="panel-collapse collapse">
                        <div class="panel-body">
                            <div class="col-md-8">
                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo.
                            </div>

                            <div class="col-md-4">

                                <img src="<?php echo base_url() ?>/site_asset/img/deployment.jpg">

                            </div>
                        </div>
                    </div>
                </div><!-- .panel -->
                <div class="panel">
                    <div class="panel-heading">
                        <a class="panel-title collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseSix">
                            6th Phase: Maintanence Phase
                        </a>
                    </div>
                    <div id="collapseSix" class="panel-collapse collapse">
                        <div class="panel-body">
                            Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo.
                        </div>
                    </div>
                </div><!-- .panel -->

            </div><!-- .panel-group -->
        </div><!-- .col-lg-8.col-md-8.col-lg-offset-1.col-lg-push-3.col-md-push-4 -->

        <!-- Sidebar -->
        <div class="col-lg-3 col-md-4 col-lg-pull-9 col-md-pull-8">
            <div class="space-top-3x visible-sm visible-xs"></div>
            <aside class="sidebar space-bottom-2x">
                <section class="widget widget_categories">
                    <h3 class="widget-title">
                        <i class="icon-ribbon"></i>
                       Our Services
                    </h3>
                    <ul>
                        <li><a href="#">Web Designing</a></li>
                        <li><a href="#">Logo Designing</a></li>
                        <li><a href="#">Graphics Designing</a></li>
                        <li><a href="#">Website Development</a></li>
                        <li><a href="#">Web App Development</a></li>
                        <li><a href="#">Desktop App Development</a></li>
                        <li><a href="#">Mobile App Development</a></li>
                        <li><a href="#">Content Writing</a></li>
                        <li><a href="#">Search Engine Optimization</a></li>
                        <li><a href="#">Social Media Marketing</a></li>
                    </ul>
                </section><!-- .widget.widget_categories -->

                <!-- Nav Tabs -->
                <ul class="nav-tabs" role="tablist">
                    <li class=""><a href="#tab3" role="tab" data-toggle="tab" aria-expanded="false">Vission</a></li>
                    <li class=""><a href="#tab1" role="tab" data-toggle="tab" aria-expanded="false">Mission</a></li>


                </ul><!-- .nav-tabs -->
                <!-- Tab panes -->
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane transition fade" id="tab1">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut dignissimos ipsam obcaecati corrupti modi, deserunt facere asperiores. Voluptatum laudantium ut, minus nam. Libero facilis aspernatur cumque, quisquam quod sint odit.</div>

                    <div role="tabpanel" class="tab-pane transition fade active in" id="tab3">Loremhjkjkjh ipsum dolor sit amet, consectetur adipisicing elit. Consectetur ratione nulla asperiores repellat natus dolor delectus dolorum harum sequi fugiat vero, voluptatem reiciendis autem, vel. Repellendus ea laudantium pariatur eum!</div>
                </div><!-- .tab-content -->



            </aside><!-- .sidebar -->

            <h6 class="text-normal text-muted" style="text-align: center">Proper Software Development Life cycle is followed.</h6>
            <hr class="space-bottom">
            <img src="<?php echo base_url() ?>/site_asset/img/SDLC.jpg">


            <div class="clearfix" style="margin-top: 10px"></div>

            <h6 class="text-normal text-muted" style="text-align: center">We are a Google Partner Company.</h6>
            <hr class="space-bottom">
            <img src="<?php echo base_url() ?>/site_asset/img/gpartner.jpg">

        </div>
    </div><!-- .row -->

    <!-- Topics -->
</div><!-- .container -->
<section class="fw-section border-top padding-top-3x padding-bottom" style="padding-bottom: 15px !important; background-color: rgb(85, 172, 238) !important ; padding-top: 23px !important;">
    <div class="container">

        <div class="logo-carousel" data-loop="true" data-autoplay="true" data-interval="4000">
            <div class="inner">
                <a href="#"><img src="<?php echo base_url() ?>site_asset/img/logos/01.jpg" alt="Logo"></a>
                <a href="#"><img src="<?php echo base_url() ?>site_asset/img/logos/05.jpg" alt="Logo"></a>
                <a href="#"><img src="<?php echo base_url() ?>site_asset/img/logos/03.jpg" alt="Logo"></a>
                <a href="#"><img src="<?php echo base_url() ?>site_asset/img/logos/04.jpg" alt="Logo"></a>
                <a href="#"><img src="<?php echo base_url() ?>site_asset/img/logos/05.jpg" alt="Logo"></a>
                <a href="#"><img src="<?php echo base_url() ?>site_asset/img/logos/06.jpg" alt="Logo"></a>
            </div>
        </div><!-- .logo-carousel -->
    </div><!-- .container -->
</section>
<!-- Scroll To Top Button -->
<a href="#" class="scroll-to-top-btn">
    <i class="icon-arrow-up"></i>
</a><!-- .scroll-to-top-btn -->
