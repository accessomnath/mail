<section class="page-title">
    <div class="container">
        <div class="inner">
            <div class="column">
                <div class="title">
                    <h1>Blogs</h1>
                </div><!-- .title -->
            </div><!-- .column -->
            <div class="column">
                <div class="breadcrumbs">
                    <a href="<?php echo base_url() ?>">Home</a>
                    <span class="delimiter"><i class="icon-arrow-right"></i></span>
                    <span>Blog</span>
                </div><!-- .breadcrumbs -->
            </div><!-- .column -->
        </div>
    </div>
</section><!-- .page-title -->

<!-- Content -->
<div class="container">
    <section class="grid isotope-grid col-2">
        <div class="gutter-sizer"></div>
        <div class="grid-sizer"></div>

        <!-- Post -->
        <div class="grid-item">
            <article class="post-item">
                <a href="post-no-sidebar.html" class="post-thumb waves-effect">
                    <img src="<?php echo base_url() ?>site_asset/img/blog/post01.jpg" alt="Post01">
                </a><!-- .post-thumb -->
                <div class="post-body">
                    <div class="post-meta">
                        <div class="column">
                  <span>
                    <i class="icon-head"></i>
                    <a href="#">Bedismo</a>
                  </span>
                            <span>in</span>
                            <span>
                    <i class="icon-ribbon"></i>
                    <a href="#">Support</a>
                  </span>
                            <span class="post-comments">
                    <i class="icon-speech-bubble"></i>
                    <a href="#">12</a>
                  </span>
                        </div>
                        <div class="column"><span>24.12.2015</span></div>
                    </div><!-- .post-meta -->
                    <a href="post-no-sidebar.html" class="post-title">
                        <h3>Reading Design &amp; Typing Art</h3>
                    </a>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud ullamco laboris nisi ut aliquip ex ea co...</p>
                    <a href="post-no-sidebar.html">Read More</a>
                </div><!-- .post-body -->
            </article><!-- .post-item -->
        </div><!-- .grid-item -->

        <!-- Post -->
        <div class="grid-item">
            <article class="post-item format-video">
                <a href="post-no-sidebar.html" class="post-thumb waves-effect">
                    <img src="<?php echo base_url() ?>site_asset/img/blog/post02.jpg" alt="Post02">
                </a><!-- .post-thumb -->
                <div class="post-body">
                    <div class="post-meta">
                        <div class="column">
                            <span class="post-format"></span>
                            <span>
                    <i class="icon-head"></i>
                    <a href="#">Rokaux</a>
                  </span>
                            <span>in</span>
                            <span>
                    <i class="icon-ribbon"></i>
                    <a href="#">Technology</a>
                  </span>
                            <span class="post-comments">
                    <i class="icon-speech-bubble"></i>
                    <a href="#">10</a>
                  </span>
                        </div>
                        <div class="column"><span>18.12.2015</span></div>
                    </div><!-- .post-meta -->
                    <a href="post-no-sidebar.html" class="post-title">
                        <h3>Sounds &amp; Stars</h3>
                    </a>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud ullamco laboris nisi ut aliquip ex ea co...</p>
                    <a href="post-no-sidebar.html">Read More</a>
                </div><!-- .post-body -->
            </article><!-- .post-item -->
        </div><!-- .grid-item -->

        <!-- Post -->
        <div class="grid-item">
            <article class="post-item format-gallery">
                <a href="post-no-sidebar.html" class="post-thumb waves-effect">
                    <img src="<?php echo base_url() ?>site_asset/img/blog/post03.jpg" alt="Post03">
                </a><!-- .post-thumb -->
                <div class="post-body">
                    <div class="post-meta">
                        <div class="column">
                            <span class="post-format"></span>
                            <span>
                    <i class="icon-head"></i>
                    <a href="#">Dencik</a>
                  </span>
                            <span>in</span>
                            <span>
                    <i class="icon-ribbon"></i>
                    <a href="#">History</a>
                  </span>
                            <span class="post-comments">
                    <i class="icon-speech-bubble"></i>
                    <a href="#">23</a>
                  </span>
                        </div>
                        <div class="column"><span>25.11.2015</span></div>
                    </div><!-- .post-meta -->
                    <a href="post-no-sidebar.html" class="post-title">
                        <h3>History &amp; Physics</h3>
                    </a>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud ullamco laboris nisi ut aliquip ex ea co...</p>
                    <a href="post-no-sidebar.html">Read More</a>
                </div><!-- .post-body -->
            </article><!-- .post-item -->
        </div><!-- .grid-item -->

        <!-- Post -->
        <div class="grid-item">
            <article class="post-item">
                <div class="post-body">
                    <div class="post-meta">
                        <div class="column">
                            <span class="post-format"></span>
                            <span>
                    <i class="icon-head"></i>
                    <a href="#">Bedismo</a>
                  </span>
                            <span>in</span>
                            <span>
                    <i class="icon-ribbon"></i>
                    <a href="#">History</a>
                  </span>
                            <span class="post-comments">
                    <i class="icon-speech-bubble"></i>
                    <a href="#">9</a>
                  </span>
                        </div>
                        <div class="column"><span>16.11.2015</span></div>
                    </div><!-- .post-meta -->
                    <a href="post-no-sidebar.html" class="post-title">
                        <h3>Planets &amp; Kaleidoscopes</h3>
                    </a>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud ullamco laboris nisi ut aliquip ex ea co...</p>
                    <a href="post-no-sidebar.html">Read More</a>
                </div><!-- .post-body -->
            </article><!-- .post-item -->
        </div><!-- .grid-item -->

        <!-- Post -->
        <div class="grid-item">
            <article class="post-item format-link">
                <div class="post-body">
                    <div class="post-meta">
                        <div class="column">
                            <span class="post-format"></span>
                            <span>
                    <i class="icon-head"></i>
                    <a href="#">Bedismo</a>
                  </span>
                            <span>in</span>
                            <span>
                    <i class="icon-ribbon"></i>
                    <a href="#">Technology</a>
                  </span>
                            <span class="post-comments">
                    <i class="icon-speech-bubble"></i>
                    <a href="#">33</a>
                  </span>
                        </div>
                        <div class="column"><span>07.11.2015</span></div>
                    </div><!-- .post-meta -->
                    <a href="post-no-sidebar.html" class="post-title">
                        <h3>From Wonderplants to Netflix-binging, here's some of our favorite discoveries</h3>
                    </a>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud ullamco laboris nisi ut aliquip ex ea co...</p>
                    <a href="post-no-sidebar.html">Read More</a>
                </div><!-- .post-body -->
            </article><!-- .post-item -->
        </div><!-- .grid-item -->
    </section><!-- .grid.isotope-grid.col-2 -->

    <!-- Pagination -->
    <section class="pagination">
        <div class="nav-links">
            <a href="#">1</a>
            <a href="#">2</a>
            <span class="current">3</span>
            <a href="#">4</a>
            <span>...</span>
            <a href="#">12</a>
        </div>
    </section><!-- .pagination -->
</div><!-- .container -->

<!-- Scroll To Top Button -->
<a href="#" class="scroll-to-top-btn">
    <i class="icon-arrow-up"></i>
</a><!-- .scroll-to-top-btn -->
