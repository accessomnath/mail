<section class="page-title">

</section><!-- .page-title -->

<!-- Container -->
<div class="container">
    <div class="row">

        <!-- Content -->
        <div class="col-lg-12 col-md-12">
            <h3 align="center">Website Development</h3>

            <div class="image-carousel space-bottom-2x">
                <div class="inner">
                    <img src="<?php echo base_url() ?>site_asset/img/pricing/growth.jpg" alt="Image">

                </div>
            </div><!-- .image-carousel -->


            <div class="col-md-9 col-lg-9">
                <h4>Website Development Solution</h4>
                <p>Gone are those days when entrepreneurs used to promote their business on television. Now it is the era of internet. If you want to make your business big and very big then you have to have your presence over huge number of customers across the border. This can only be possible when you are online.
                    Moreover integrating technology into your business can definitely help your business grow bigger and bigger. We will provide you end to end support in solving your problems and achieving your goal. We provide full integrated CMS solution, Ecommerce Solution and many other functional based development solutions.
                    </p>

                <p>We work on various kind of latest technologies that are in market. We follow a quality standard and that is the prime focus of our institution. We mainly work on the PHP and C# language for Server side programming. On client side we do use J-Query, JavaScript , Angular JS. In Php we work on different kind of Frameworks as per client requirement. We are proficient in Laravel Website Development and Code Ignitor website development. We also have a dedicated team for Wordpress Website development. Core PHP and .NET Framework is the other area of expertise that we have in the area of Web development.</p>


                <h4>Frameworks that we are master in</h4>

<div class="col-md-5">
               <ul>
                    <li>Core Php</li>
                    <li>Wordpress</li>
                    <li>Laravel</li>
                    <li>Code Ignitor</li>
                    <li>Magento</li>
                    <li>.NET</li>
                </ul>
</div>
                <div class="col-md-7">

                    <img src="<?php echo base_url() ?>site_asset/img/pricing/software.png" alt="Image">
                </div>

                <div class="clearfix"></div>
                <p>These technologies are latest in the market and we take the pre existing advantage from these to make your business ideas to put into the practical implementation. As a backend database we use MYSQL, MS Server, Firebase and Mongo Db. We trying to expand our expertise to JAVA development and explore other languages like PYTHON and RUBY. </p>



                <h4>How Semicolon IT do Web Deveopment Solutions?</h4>
                <img src="<?php echo base_url() ?>site_asset/img/pricing/develop.jpg" alt="Image" style="float: right">

                <p>We always focus on solving your problems and helping your business to achieve its Goal. In doing that we provide you with the best technical support that your organization requires. We maintain a standard Software development life cycle. That cycle begins from the first day interaction with you till the date you are fully satisfied with the services that we provide. Our technical team will evaluate all the business ascpects of your idea, discuss about your project idea and try to give you the ultimate resolution</p>

                <p><strong>Stage 1 of SDLC: Planning</strong> This is the first stage of any project. Our team will contact you regarding your project budget and the timeline and business ideas. After we got all the requirement we will do a proper planning regarding the workflow of the project.</p>

                <p><strong>Stage 2 of SDLC: Analysis</strong> This is the Second phase of the project life cycle. Here after getting all the required information from your part we will do a vivid research regarding your requirement. According to the requirement resources will be allocated to the project. We will also provide a detailed Scope of work on which both the parties must agree upon.</p>

                <p><strong>Stage 3 of SDLC: Design</strong> Once we are agreed upon a common scope of work then we will proceed with the dsigning phase and from here real web Development work starts. This phase deals with the look and feel of the website. We may provide with template or Custom PSD mock Ups as per the package you have taken. We will use HTML 5, CSS 3, JavaScript, JQuery and Angular if required to build a world class and morder Website Design for your Business. We will ask for the feedback from your end. If you are satisfied then we will move to the next step of Development else again we will make changes according to your feed back and again wait for your approval.</p>

                <p><strong>Stage 4 of SDLC: Development</strong> This is the stage where all the functional implementaions are done. Once the project is in this stage we choose the suitable platform for your project. It may be done in PHP MVC framework or in Wordpress or in .NET. Functionalies like data collection, form submissision, Payment gateway integration, booking selling etc are implemented.</p>


                <p><strong>Stage 5 of SDLC: Testing & Deployment</strong> After the Development phase is over or else max part of funtional areas of the website is cover the project reaches the testing phase. In this stage the developemd application is tested with dummy data and under different parameters and situations. If Bugs or error comes out, our developer fixes those. After few round of cheking and testing the Software is Quality assured and they are ready to hit the Competetive market</p>

                <p><strong>Stage 6 of SDLC: Maintenance</strong> Maintenance is a integral part of any software development life cycle. As the Application goes through different kinds of new practical scenerios changes in it are ought to be necessary. So we provide our Clients wilth one year free maintenance.</p>

                <div class="clearfix"></div>

                <h4>Semicolon IT have experience in dealing with websites like</h4>
                <div class="row padding-top" style="text-align: center">
                    <div class="col-sm-4 col-xs-6 padding-bottom iconlogo">
                        <p class="space-bottom-none">Blog Websites</p>
                        <img src="<?php echo base_url() ?>site_asset/img/pricing/blog.png" class="block-center" alt="Feature">
                    </div>
                    <div class="col-sm-4 col-xs-6 padding-bottom iconlogo">
                        <p class="space-bottom-none">Booking Website</p>
                        <img src="<?php echo base_url() ?>site_asset/img/pricing/booking.png" class="block-center" alt="Feature">
                    </div>
                    <div class="col-sm-4 col-xs-6 padding-bottom iconlogo">
                        <p class="space-bottom-none">CMS based Website</p>
                        <img src="<?php echo base_url() ?>site_asset/img/pricing/cms.png" class="block-center" alt="Feature">
                    </div>
                    <div class="col-sm-4 col-xs-6 padding-bottom iconlogo">
                        <p class="space-bottom-none">CRM Base Website</p>
                        <img src="<?php echo base_url() ?>site_asset/img/pricing/crm.png" class="block-center" alt="Feature">
                    </div>
                    <div class="col-sm-4 col-xs-6 padding-bottom iconlogo">
                        <p class="space-bottom-none">Ecommerce Website</p>
                        <img src="<?php echo base_url() ?>site_asset/img/pricing/ecomm.png" class="block-center" alt="Feature">
                    </div>
                    <div class="col-sm-4 col-xs-6 padding-bottom iconlogo">
                        <p class="space-bottom-none">Dating and Matrimonial</p>
                        <img src="<?php echo base_url() ?>site_asset/img/pricing/dating.gif" class="block-center" alt="Feature">
                    </div>

                    <div class="col-sm-4 col-xs-6 padding-bottom iconlogo">
                        <p class="space-bottom-none">Health Care websites</p>
                        <img src="<?php echo base_url() ?>site_asset/img/pricing/healthcare.jpg" class="block-center" alt="Feature">
                    </div>

                    <div class="col-sm-4 col-xs-6 padding-bottom iconlogo">
                        <p class="space-bottom-none">Educational websites</p>
                        <img src="<?php echo base_url() ?>site_asset/img/pricing/education.gif" class="block-center" alt="Feature">
                    </div>
                </div>




            </div>


            <div class="col-lg-3 col-md-3">
                <div class="space-top-3x visible-sm visible-xs"></div>
                <aside class="sidebar">


                    <section class="widget widget_categories">
                        <h3 class="widget-title">
                            <i class="icon-ribbon"></i>
                            Other Services
                        </h3>
                        <ul>
                            <li><a href="#">Website Development</a></li>
                            <li><a href="#">Web Application Development</a></li>
                            <li><a href="#">Mobile App Development</a></li>
                            <li><a href="#">Digital Marketing</a></li>
                            <li><a href="#">Search Engine Optimization</a></li>
                            <li><a href="#">Content Writing</a></li>
                            <li><a href="#">Hosting</a></li>

                        </ul>
                    </section><!-- .widget.widget_categories -->


                    <section class="widget widget_recent_posts">
                        <h3 class="widget-title">
                            <i class="icon-paper"></i>
                            Click To get Best Pricing plans for your Resquirement
                        </h3>
                        <div class="pricing-plan" style="border: none !important;">
                            <div class="pricing-header">

                                <a href="">
                                    <img src="<?php echo base_url() ?>site_asset/img/pricing.jpg" alt="Pricing">
                                </a>
                            </div>


                        </div>


                    </section>


                    <section class="widget widget_recent_posts">
                        <h3 class="widget-title">
                            <i class="icon-paper"></i>
                            Working Technologies
                        </h3>
                        <ul>
                            <li><a href="#">Website Development</a></li>
                            <li><a href="#">Web Application Development</a></li>
                            <li><a href="#">Mobile App Development</a></li>
                            <li><a href="#">Digital Marketing</a></li>
                            <li><a href="#">Search Engine Optimization</a></li>
                            <li><a href="#">Content Writing</a></li>
                            <li><a href="#">Hosting</a></li>

                        </ul>
                        <!-- .item -->
                    </section><!-- .widget.widget_recent_posts -->


                    <section class="widget widget_recent_posts">
                        <h3 class="widget-title">
                            <i class="icon-paper"></i>
                            Wordpress Development
                        </h3>
                        <a href="">
                            <img src="<?php echo base_url() ?>site_asset/img/pricing/internet.png" alt="Pricing">
                        </a>
                        <!-- .item -->
                    </section><!-- .widget.widget_recent_posts -->

                    <section class="widget widget_recent_posts">
                        <h3 class="widget-title">
                            <i class="icon-paper"></i>
                            Codeignitor Development
                        </h3>
                        <a href="">
                            <img src="<?php echo base_url() ?>site_asset/img/pricing/cod-icon.png" alt="Pricing">
                        </a>
                        <!-- .item -->
                    </section><!-- .widget.widget_recent_posts -->

                    <section class="widget widget_recent_posts">
                        <h3 class="widget-title">
                            <i class="icon-paper"></i>
                            Laravel Development
                        </h3>
                        <a href="">
                            <img src="<?php echo base_url() ?>site_asset/img/pricing/laravel.jpg" alt="Pricing">
                        </a>
                        <!-- .item -->
                    </section><!-- .widget.widget_recent_posts -->


                    <section class="widget widget_recent_posts">
                        <h3 class="widget-title">
                            <i class="icon-paper"></i>
                            MAgento Development
                        </h3>
                        <a href="">
                            <img src="<?php echo base_url() ?>site_asset/img/pricing/magento.png" alt="Pricing">
                        </a>
                        <!-- .item -->
                    </section><!-- .widget.widget_recent_posts -->

                </aside><!-- .sidebar -->
            </div><!-- .col-lg-3.col-md-4 -->



            <!-- Comments -->

        </div><!-- .col-lg-9.col-md-8 -->

        <!-- Sidebar -->






    </div><!-- .row -->



</div><!-- .container -->

<!-- Scroll To Top Button -->
<a href="#" class="scroll-to-top-btn">
    <i class="icon-arrow-up"></i>
</a><!-- .scroll-to-top-btn -->
<div class="clearfix" style="padding-bottom: 10px"></div>