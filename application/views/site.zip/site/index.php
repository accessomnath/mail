<!--  Page Content, class footer-fixed if footer is fixed  -->
<div id="page-content" class="header-static footer-fixed">
    <!--  Slider  -->
    <div id="flexslider" class="fullpage-wrap small">
        <ul class="slides">
            <li style="background-image:url('<?php echo base_url()  ?>site_asset/assets/img/banner.jpg')">
                <div class="text left typed">
                    <h2 class="title white left margin-bottom" style="font-weight: bold; color: #dc3056 !important;">STRIVE | INNOVATE | REPEAT</h2>
                    <h1 class="medium white ">We are Semicolon ITES</h1><p><span id="typed" class="big white" data-typed-first="Building Enterprises" data-typed-second="Innovating the Digital World"></span></p>
                    <p class="heading white left margin-bottom">Creating fusions in Web Design &
                        Transforming ideas into reality
                    </p>
                    <a href="#" class="btn-alt small active margin-null">Read More</a>
                </div>
                <div class="gradient dark"></div>
            </li>
        </ul>
    </div>
    <!--  END Slider  -->
    <div id="home-wrap" class="content-section fullpage-wrap">
        <!-- Services -->



        <section class="do-sevice-section" id="do-sevice-section">
            <div class="container">

                <div class="col-md-12 padding-leftright-null text-center">

                    <div class="padding-md">
                        <h3 class="grey big margin-bottom-small center">Our Services</h3>
                        <p class="heading center margin-bottom grey">We provide top-notch Web development and mobile application development  services to their clients. Semicolon ITES don’t count customers until we can bring a smile in their faces with the work that we do. Below are the few service that we often offer to our clients</p>
                    </div>
                </div>

                <div class="row">

                    <!-- DESIGN -->
                    <div class="do-service-container">
                        <div class="do-service-container-inner">
                            <div class="do-front-part">
                                <div class="do-front-content">
                                    <i class="fa fa-desktop"></i>
                                    <h3>Web development</h3>
                                </div>
                            </div>

                            <div class="do-back-part">
                                <div class="do-back-content">
                                    <h3>Web development</h3>
                                    <p> Not getting the proper way to boost your Business? We are here to assist you. We are developing the most amazing and innovative solutions for every business through the years. </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- PRODUCTS -->
                    <div class="do-service-container">
                        <div class="do-service-container-inner">
                            <div class="do-front-part">
                                <div class="do-front-content">
                                    <i class="fa fa-paint-brush"></i>
                                    <h3>Web design</h3>
                                </div>
                            </div>

                            <div class="do-back-part">
                                <div class="do-back-content">
                                    <h3>Web design</h3>
                                    <p> Want an attractive look and feel for your website ? Welcome to the era of eye catching visuals which will make your website appealing instantly.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- AWARDS -->
                    <div class="do-service-container">
                        <div class="do-service-container-inner">
                            <div class="do-front-part">
                                <div class="do-front-content">
                                    <i class="fa fa-tablet"></i>
                                    <h3>Mobile App development</h3>
                                </div>
                            </div>

                            <div class="do-back-part">
                                <div class="do-back-content">
                                    <h3>Mobile App development</h3>
                                    <p>Avail the most exclusive Mobile Applications we design, which will not only help grow your business, also it will enhance its reachability to the maximum.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- PARTNERS -->
                    <div class="do-service-container">
                        <div class="do-service-container-inner">
                            <div class="do-front-part">
                                <div class="do-front-content">
                                    <i class="fa fa-pencil"></i>
                                    <h3>Graphics Design</h3>
                                </div>
                            </div>

                            <div class="do-back-part">
                                <div class="do-back-content">
                                    <h3>Graphics Design</h3>
                                    <p>From Logo designs to Corporate Presentations, we have been constantly adding value to our customers.  We design to symbolize your business. We will provide the perfect branding for your business.</p>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="do-service-container" style="margin-top: 1px">
                        <div class="do-service-container-inner">
                            <div class="do-front-part">
                                <div class="do-front-content">
                                    <i class="fa fa-globe"></i>
                                    <h3>Digital Marketing</h3>
                                </div>
                            </div>

                            <div class="do-back-part">
                                <div class="do-back-content">
                                    <h3>Digital Marketing</h3>
                                    <p> Want to flourish your Business in the Digital World ? We provide the best programs for Web Mailers, SEO, Ad Campaigns and many more for your Business to reach maximum audience. </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="do-service-container" style="margin-top: 1px">
                        <div class="do-service-container-inner">
                            <div class="do-front-part">
                                <div class="do-front-content">
                                    <i class="fa fa-database"></i>
                                    <h3>Domain Hostings</h3>
                                </div>
                            </div>

                            <div class="do-back-part">
                                <div class="do-back-content">
                                    <h3>Domain Hostings</h3>
                                    <p> Let’s make your business reachable to the entire World. We provide a strong and robust Domain and Hosting services which will definitely make your Enterprise stable in a gradual way. </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="do-service-container" style="margin-top: 1px">
                        <div class="do-service-container-inner">
                            <div class="do-front-part">
                                <div class="do-front-content">
                                    <i class="fa fa-search-plus"></i>
                                    <h3>Software Testing</h3>
                                </div>
                            </div>

                            <div class="do-back-part">
                                <div class="do-back-content">
                                    <h3>Software Testing</h3>
                                    <p> Want to flourish your Business in the Digital World ? We provide the best programs for Web Mailers, SEO, Ad Campaigns and many more for your Business to reach maximum audience. </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="do-service-container" style="margin-top: 1px">
                        <div class="do-service-container-inner">
                            <div class="do-front-part">
                                <div class="do-front-content">
                                    <i class="fa fa-headphones"></i>
                                    <h3>BPO Services</h3>
                                </div>
                            </div>

                            <div class="do-back-part">
                                <div class="do-back-content">
                                    <h3>BPO Services</h3>
                                    <p> Let’s make your business reachable to the entire World. We provide a strong and robust Domain and Hosting services which will definitely make your Enterprise stable in a gradual way. </p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <!-- END Services -->
        <!-- Section Image Background -->
        <div class="row margin-leftright-null first-section box-shadow-inset">
            <div class="col-md-6 padding-leftright-null">
                <div data-responsive="parent-height" data-responsive-id="about" class="text color-background">
                    <div class="padding-lg padding-md-topbottom-null">
                        <h3 class="big white margin-bottom-small">We are Semicolon ITES, <br> a company working by heart</h3>
                        <p class="heading left white">An Idea remains an “IDEA” only till it is implemented. Let’s ‘STRIVE’, ‘INNOVATE’, ‘REPEAT’, and we can definitely change the world, “TOGETHER”.  We don’t just present you a dream of Success; we help you achieve it, consistently. Learn more about Semicolon ITES </p>
                        <a href="#" class="btn-pro white z-index">more info</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 padding-leftright-null">
<div data-responsive="child-height" data-responsive-id="about" class="bg-img" style="background-image: url('<?php echo base_url()?>/site_asset/assets/img/business1.jpg'); height: 603px;"></div>

            </div>
        </div>
        <!-- END Section Image Background -->
        <!-- Concept -->
        <div class="row no-margin" >
            <div class="col-md-12 padding-leftright-null">
                <div class="col-md-4 padding-leftright-null">
                    <div class="text padding-md-bottom-null">
                        <em class="number">01.</em>
                        <div class="service-content medium">
                            <h6 class="heading uppercase color padding-onlytop-sm">Our Mission</h6>
                            <p class="margin-bottom-null">Our mission is to strive hard for the growth of technology and business togather. We stand with a goal of helping business with our expertise in the Technology   </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 padding-leftright-null">
                    <div class="text padding-md-bottom-null">
                        <em class="number">02.</em>
                        <div class="service-content medium">
                            <h6 class="heading uppercase color padding-onlytop-sm">Our Vision</h6>
                            <p class="margin-bottom-null">Our vission is to incorporate will all the latest tecnology in the IT Inovative market. We will learn and implement those to make our clients do business with ease and with high ROR. </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 padding-leftright-null">
                    <div class="text">
                        <em class="number">03.</em>
                        <div class="service-content medium">
                            <h6 class="heading uppercase color padding-onlytop-sm">Our Values</h6>
                            <p class="margin-bottom-null">We are driven by strong ethics and values of IT business. We are obliged to play a fair game with all our clients, employees and stakeholders. We can't be good to all but we are always fair to all.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END Concept -->
        <!-- Skills -->
        <div class="row margin-leftright-null" style="background-color: antiquewhite">
            <div class="col-lg-8 padding-leftright-null">
                <div data-responsive="parent-height" data-responsive-id="adv" class="text">
                    <h2 class="margin-bottom-null title left">Why Us</h2>
                    <div class="padding-onlytop-md">
                        <h3 class="grey big margin-bottom-small">Tech lovers,<br> excellent developers</h3>
                        <p class="heading left margin-bottom">We have a excellent team of web developers and designers and business experts who are well capable of handling and nurturing your dreams.</p>
                        <p>We differentialte ourselves from others on certain parameters which are quality, punctuality, good customer support, expertise in the knowledge of the technology, understanding the business requirements and delivering the same. We not only help you to develop your dream project, but we also try to add some more value to your business. </p>
                        <a href="#" class="btn-simple">More info</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 padding-leftright-null">
                <div data-responsive="child-height" data-responsive-id="adv" class="text height-auto-lg vertical-align-outer" style="height: 517px;">
                    <div class="color-background box-shadow vertical-align-inner text responsive-padding-sm padding-md-topbottom-null" style="padding: 25px !important;">
                        <blockquote class="heading white" style="font-size: 25px !important;">Even APPLE, SAMSUNG, FERRARI,  needs a Website for their business. How can you be so sure that your business don't need a one?</blockquote>
                    </div>
                </div>
            </div>
        </div>
        <!-- END Skills -->
        <!--  Projects Showcase  -->
        <div class="row margin-leftright-null fullpage-wrap">
            <div class="col-md-12 padding-leftright-null text-center">
                <div class="col-md-12 padding-leftright-null text-center">
                    <div class="text padding-md-bottom-null">
                        <h2 class="margin-bottom-null title center">Our Portfoilo</h2>
                        <h3 class="grey big margin-bottom-small padding-onlytop-md">One work, many passions</h3>

                    </div>
                </div>
            </div>
        </div>

        <section id="projects-filters" style="padding-top: 0px !important;" class="wrap-filters-minimal text-center">
            <!--  Filters  -->
            <div class="row">
                <div class="col-sm-12">
                    <ul class="col-md-12 filters padding-leftright-null">
                        <li data-filter="*" class="is-checked">All</li>
                        <li data-filter=".ecommerce" class="">Ecommerce</li>
                        <li data-filter=".website" class="">Website</li>
                        <li data-filter=".health" class="">Health</li>
                        <li data-filter=".logo" class="">Logo</li>
                    </ul>
                </div>
            </div>
            <!--  END Filters  -->
        </section>

        <section id="projects" data-isotope="load-simple">
            <div class="projects-items equal four-columns" style="position: relative; height: 674.5px;">
                <div class="one-item health" style="position: absolute; left: 0px; top: 0px;">
                    <div class="image-bg" style="background-image:url(<?php echo base_url()  ?>site_asset/assets/img/mddermatics_com.png)"></div>
                    <div class="content">
                                    <span class="icon">
                                        <i class="material-icons">add</i>
                                    </span>
                        <div class="text">
                            <h4>www.mddermatics.com</h4>
                            <h3 class="big">mddermatics</h3>
                        </div>
                        <a href="http://www.mddermatics.com" target="_blank" class="link"></a>
                    </div>
                </div>
                <div class="one-item logo" style="position: absolute; left: 337px; top: 0px;">
                    <div class="image-bg" style="background-image:url(<?php echo base_url()  ?>site_asset/assets/img/set3.jpg)"></div>
                    <div class="content">
                                    <span class="icon">
                                        <i class="material-icons">add</i>
                                    </span>
                        <div class="text">
                            <h4>Branding / Identity</h4>
                            <h3 class="big">Logo Design</h3>
                        </div>
                        <a href="#" class="link"></a>
                    </div>
                </div>
                <div class="one-item ecommerce" style="position: absolute; left: 674px; top: 0px;">
                    <div class="image-bg" style="background-image:url(<?php echo base_url()  ?>site_asset/assets/img/vonronen_com.png)"></div>
                    <div class="content">
                                    <span class="icon">
                                        <i class="material-icons">add</i>
                                    </span>
                        <div class="text">
                            <h4>www.vonronen.com</h4>
                            <h3 class="big">Vonronen</h3>
                        </div>
                        <a href="http://www.vonronen.com/" target="_blank"class="link"></a>
                    </div>
                </div>
                <div class="one-item website" style="position: absolute; left: 1011px; top: 0px;">
                    <div class="image-bg" style="background-image:url(<?php echo base_url()  ?>site_asset/assets/img/coffscoastwatercartage_com.png)"></div>
                    <div class="content">
                                    <span class="icon">
                                        <i class="material-icons">add</i>
                                    </span>
                        <div class="text">
                            <h4 style="font-size: 12px">www.coffscoastwatercartage.com</h4>
                            <h3 class="big">coffs coast water cartage</h3>
                        </div>
                        <a href="http://www.coffscoastwatercartage.com" target="_blank" class="link"></a>
                    </div>
                </div>
                <div class="one-item ecommerce" style="position: absolute; left: 0px; top: 337px;">
                    <div class="image-bg" style="background-image:url(<?php echo base_url()  ?>site_asset/assets/img/www.weldingmart_com.png)"></div>
                    <div class="content">
                                    <span class="icon">
                                        <i class="material-icons">add</i>
                                    </span>
                        <div class="text">
                            <h4>www.weldingmart.com</h4>
                            <h3 class="big">weldingmart</h3>
                        </div>
                        <a href="http://www.weldingmart.com" target="_blank" class="link"></a>
                    </div>
                </div>
                <div class="one-item ecommerce" style="position: absolute; left: 337px; top: 337px;">
                    <div class="image-bg" style="background-image:url(<?php echo base_url()  ?>site_asset/assets/img/vsadesigns_com.png)"></div>
                    <div class="content">
                                    <span class="icon">
                                        <i class="material-icons">add</i>
                                    </span>
                        <div class="text">
                            <h4>www.vsadesigns.com</h4>
                            <h3 class="big">vsadesigns</h3>
                        </div>
                        <a href="http://www.vsadesigns.com" target="_blank" class="link"></a>
                    </div>
                </div>
                <div class="one-item digital logo" style="position: absolute; left: 674px; top: 337px;">
                    <div class="image-bg" style="background-image:url(<?php echo base_url()  ?>site_asset/assets/img/set1.jpg)"></div>
                    <div class="content">
                                    <span class="icon">
                                        <i class="material-icons">add</i>
                                    </span>
                        <div class="text">
                            <h4>Social / Web Development</h4>
                            <h3 class="big">Logo Design</h3>
                        </div>
                        <a href="#" class="link"></a>
                    </div>
                </div>
                <div class="one-item website health" style="position: absolute; left: 1011px; top: 337px;">
                    <div class="image-bg" style="background-image:url(<?php echo base_url()  ?>site_asset/assets/img/www.braininjurycounsel_com.png)"></div>
                    <div class="content">
                                    <span class="icon">
                                        <i class="material-icons">add</i>
                                    </span>
                        <div class="text">
                            <h4 style="font-size: 14px">www.braininjurycounsel.com</h4>
                            <h3 class="big">Brain Injury Counsel</h3>
                        </div>
                        <a href="http://www.braininjurycounsel.com" target="_blank" class="link"></a>
                    </div>
                </div>
            </div>
        </section>










        <!--  END Projects Showcase  -->
        <!--  Section Image Background with overlay  -->
        <div class="row margin-leftright-null grey-background">
            <div class="bg-img overlay responsive">
                <!-- Testimonials -->
                <section class="testimonials-carousel-simple col-md-12 text padding-bottom-null" style="background-color: #dc3056">
                    <div class="item padding-leftright-null">
                        <div class="text padding-top-null padding-bottom-null">
                            <blockquote class="margin-bottom-small white">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequuntur voluptatum fugiat molestias, veritatis perspiciatis laborum modi beatae placeat explicabo at laudantium aliquam, nam vero ut!</blockquote>
                            <em class="small grey-light">AC Company</em><span class="margin-null white"> John Doe</span>
                        </div>
                    </div>
                    <div class="item padding-leftright-null">
                        <div class="text padding-top-null padding-bottom-null">
                            <blockquote class="margin-bottom-small white">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequuntur voluptatum fugiat molestias, veritatis perspiciatis laborum modi beatae placeat explicabo at laudantium aliquam, nam vero ut!</blockquote>
                            <em class="small grey-light">AC Company</em><span class="margin-null white"> John Doe</span>
                        </div>
                    </div>
                </section>
                <!-- END Testimonials -->
            </div>
        </div>
        <!--  END Section Image Background with overlay  -->
        <!-- Section News -->
        <div class="row margin-leftright-null grey-background">
            <div class="col-md-4 padding-leftright-null">
                <div class="text">
                    <h2 class="margin-bottom-null title left grey">News</h2>
                    <div class="padding-onlytop-md">
                        <h3 class="grey big margin-bottom-small">Latest Posts. Stay tuned!</h3>
                        <p class="heading left margin-bottom grey">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatem dolorem voluptas quo ipsum obcaecati placeat, architecto, amet voluptatum esse officia, distinctio dignissimos minima dicta. Veniam debitis eum illum asperiores animi!</p>
                        <a href="#" class="btn-alt active shadow small margin-null">Read all news</a>
                    </div>
                </div>
            </div>
            <div class="col-md-8 text" id="news">
                <!-- Single News -->
                <div class="col-sm-6 single-news">
                    <article>
                        <img src="<?php echo base_url()  ?>site_asset/assets/img/news1.jpg" alt="">
                        <div class="content">
                                        <span class="read">
                                            <i class="material-icons">subject</i>
                                        </span>
                            <h3>Meetup In Rome</h3>
                            <span class="category">Tech</span>
                            <span class="category">Social</span>
                            <span class="date">02.11.2016</span>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Expedita, voluptas corporis. Maxime sapiente, adipisci laborum.</p>
                        </div>
                        <a href="#" class="link"></a>
                    </article>
                </div>
                <!-- END Single News -->
                <div class="col-sm-6 single-news">
                    <article>
                        <img src="<?php echo base_url()  ?>site_asset/assets/img/news3.jpg" alt="">
                        <div class="content">
                                        <span class="read">
                                            <i class="material-icons">subject</i>
                                        </span>
                            <h3>Brand Power</h3>
                            <span class="category">People</span>
                            <span class="category">Topic</span>
                            <span class="date">12.05.2016</span>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Expedita, voluptas corporis. Maxime sapiente, adipisci laborum.</p>
                        </div>
                        <a href="#" class="link"></a>
                    </article>
                </div>
            </div>
        </div>
        <!-- END Section News -->
        <!-- Section Partners -->

        <section class="sdsn-SocialShare">
            <ul>
                <li class="face">
                    <a href="" target="_blank" class="sdsn-socialitems">
         <span class="sdsn-socialImg"><img src="<?php echo base_url()  ?>site_asset/assets/img/icon-facebook.svg" alt="Find us on Facebook"></span>
                        <span class="sdsn-socialdes">
                            <p>Find us on</p>
                            <h6>Facebook</h6>
                        </span>
                    </a>
                </li>
                <li class="twit">
                    <a href="" target="_blank" class="sdsn-socialitems">
        <span class="sdsn-socialImg"><img src="<?php echo base_url()  ?>site_asset/assets/img/icon-twitter.svg" alt="Follow us on Twitter"></span>
                        <span class="sdsn-socialdes">
                            <p>Follow us on</p>
                            <h6>Twitter</h6>
                        </span>
                    </a>
                </li>
                <li class="in">
                    <a href="" target="_blank" class="sdsn-socialitems">
  <span class="sdsn-socialImg"><img src="<?php echo base_url()  ?>site_asset/assets/img/icon-linkedin.svg" alt="Follow us on LinkedIn"></span>
                        <span class="sdsn-socialdes">
                            <p>Follow us on</p>
                            <h6>LinkedIn</h6>
                        </span>
                    </a>
                </li>
                <li class="inst">
                    <a href="" target="_blank" class="sdsn-socialitems">
   <span class="sdsn-socialImg"><img src="<?php echo base_url()  ?>site_asset/assets/img/icon-instagram.svg" alt="Follow us on Instagram"></span>
                        <span class="sdsn-socialdes">
                            <p>Follow us on</p>
                            <h6>Instagram</h6>
                        </span>
                    </a>
                </li>
            </ul>
        </section>

        <div class="row padding-md margin-leftright-null color-background">
            <div class="col-md-12 text-center">
                <h4 class="big margin-bottom-small white" style="padding-top: 45px">Need a Website?  We can help you definately. </h4>
                <a href="#" target="_blank" class="btn-alt small shadow white margin-null active">Contact Us</a>
            </div>
        </div>

        <!-- END Section Partners -->
    </div>
</div>
<!--  END Page Content, class footer-fixed if footer is fixed  -->
