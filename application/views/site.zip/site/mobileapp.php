<section class="page-title">

</section><!-- .page-title -->

<!-- Container -->
<div class="container">
    <div class="row">

        <!-- Content -->
        <div class="col-lg-12 col-md-12">
            <h3 align="center">Mobile Application Development</h3>

            <div class="image-carousel space-bottom-2x">
                <div class="inner">
                    <img src="<?php echo base_url() ?>site_asset/img/pricing/mobileapp.jpg" alt="Image">

                </div>
            </div><!-- .image-carousel -->


            <div class="col-md-9 col-lg-9">
                <h4>What is website Designing?</h4>
                <p>In this present era of internet, Mobile browsing and mobile application have gained its importance to its ulimate height. Pleople now consider mobile to fulfill there internet needs. From shoping to daily news people are now going for mobile applications. So cope up with this changing behavior of customers behavior Enterpenours need to look out for mobile app development services.  Semicolon ITES is a top mobile application development company providing mobile app for IOS, Android, Windows and Blackberry. </p>
                 <p>Our team of software developers are trully creative and skillfull to accomplish customized need of the premier clients. We develop mobile app that are robust, user friendly and can handle high potential bussiness.
                </p>

                <h4>What solution Semicolon IT provides for Mobile Application Development?</h4>

<div class="why">
              <ul>
                  <li>Experienced and skilled Developers.</li>
                  <li>We have a strong support team, helping you out at the time of your need.</li>
                  <li>We follow proper Mobile Application devlopment life cycle.</li>
                  <li>We offer time bound and cost effective service.</li>
                  <li>We work on both native and Hybrid Mobile Application .</li>
              </ul>
</div>

                <h4>Semicolon ITES's Mobile Application Development Services ?</h4>

                <div class="row">
                <h5 class="green">IOS Mobile Applications</h5>
                <p class="col-md-8">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>

                    <img class="col-md-4" src="<?php echo base_url()?>site_asset/img/ios.png" style="margin-top: -40px; margin-bottom: 30px";>
                </div>
                <div class="row">

                <h5 class="green">Android Mobile Applications</h5>
                <p class="col-md-8">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>

                    <img class="col-md-4" src="<?php echo base_url()?>site_asset/img/android.png" style="margin-top: -50px; margin-bottom: 30px;">
                </div>
                <div class="row">
                <h5 class="green">Windows Mobile Applications</h5>
                <p class="col-md-8">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>

                    <img class="col-md-4" src="<?php echo base_url()?>site_asset/img/window.png" style="margin-top: -50px; margin-bottom: 30px;">
                </div>

<div class="row">

                <h5 class="green">Blackberry Mobile Applications</h5>
                <p class="col-md-8">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>

                    <img class="col-md-4" src="<?php echo base_url()?>site_asset/img/blackberry.png" style="margin-top: -50px">
</div>
       </div>



            <div class="col-lg-3 col-md-3">


                <h4>Mobile Application Technologies that we work on?</h4>
                <img src="<?php echo base_url()?>site_asset/img/native.jpg">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
                <img src="<?php echo base_url()?>site_asset/img/hybrid.jpg">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>




                <div class="space-top-3x visible-sm visible-xs"></div>
                <aside class="sidebar">


                    <section class="widget widget_categories">
                        <h3 class="widget-title">
                            <i class="icon-ribbon"></i>
                            Other Services
                        </h3>
                        <ul>
                            <li><a href="#">Website Development</a></li>
                            <li><a href="#">Web App Development</a></li>
                            <li><a href="#">Mobile App Development</a></li>
                            <li><a href="#">Digital Marketing</a></li>
                            <li><a href="#">SEO / SEM</a></li>
                            <li><a href="#">Content Writing</a></li>
                            <li><a href="#">Hosting</a></li>

                        </ul>
                    </section><!-- .widget.widget_categories -->


                    <section class="widget widget_recent_posts">
                        <h3 class="widget-title">
                            <i class="icon-paper"></i>
                            Click To get Best Pricing plans for your Resquirement
                        </h3>
                        <div class="pricing-plan" style="border: none !important;">
                            <div class="pricing-header">

                                <a href="">
                                    <img src="<?php echo base_url() ?>site_asset/img/pricing.jpg" alt="Pricing">
                                </a>
                            </div>


                        </div>


                    </section>


<!--                    <section class="widget widget_recent_posts">-->
<!--                        <h3 class="widget-title">-->
<!--                            <i class="icon-paper"></i>-->
<!--                            Working Technologies-->
<!--                        </h3>-->
<!--                        <ul>-->
<!--                            <li><a href="#">Website Development</a></li>-->
<!--                            <li><a href="#">Web Application Development</a></li>-->
<!--                            <li><a href="#">Mobile App Development</a></li>-->
<!--                            <li><a href="#">Digital Marketing</a></li>-->
<!--                            <li><a href="#">Search Engine Optimization</a></li>-->
<!--                            <li><a href="#">Content Writing</a></li>-->
<!--                            <li><a href="#">Hosting</a></li>-->
<!---->
<!--                        </ul>-->
<!--                        <!-- .item -->
<!--                    </section><!-- .widget.widget_recent_posts -->

                </aside><!-- .sidebar -->
            </div><!-- .col-lg-3.col-md-4 -->



            <!-- Comments -->

        </div><!-- .col-lg-9.col-md-8 -->

        <!-- Sidebar -->






    </div><!-- .row -->



</div><!-- .container -->

<!-- Scroll To Top Button -->
<a href="#" class="scroll-to-top-btn">
    <i class="icon-arrow-up"></i>
</a><!-- .scroll-to-top-btn -->
