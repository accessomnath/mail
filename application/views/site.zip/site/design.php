<section class="page-title">
  
</section><!-- .page-title -->

<!-- Container -->
<div class="container">
    <div class="row">

        <!-- Content -->
        <div class="col-lg-12 col-md-12">
            <h3 align="center">Website Designing</h3>

            <div class="image-carousel space-bottom-2x">
                <div class="inner">
                    <img src="<?php echo base_url() ?>site_asset/img/design.jpg " alt="Image">

                </div>
            </div><!-- .image-carousel -->


           <div class="col-md-9 col-lg-9">
            <h4>What is website Designing?</h4>

               <div class="col-md-5" style="padding-left: 0px;">

                   <img src="<?php echo base_url()?>site_asset/img/pricing/ui.jpg" style="padding: 20px">
               </div>

               <div class="col-md-7" style="padding-left: 0px;">
               <p>Web design is a similar process of creation, with the intention of presenting the content on electroniv web pages, which the end users can access through the internet with the help of a web browser</p>

            <p>Website Design is the procedure of gathering ideas, and aesthetically implementing and arranging  them, followed  by few principles for a specific intention. Web design is a similar process of creation, with the intention of presenting the content on electronic web pages, which the end-users can access through the internet with the help of a web browser.</p>
               </div>

               <div class="clearfix"></div>

            <div class="col-md-7" style="padding-left: 0px;">

               <h4>What solution Semicolon IT provides for Web Designing?</h4>
               <p>SemiColon It understands that in this kind of highly competetive online market designs plays a very vital role. We make sure that your website must not become any other simple web Urls. We provide our customers with the latest website designing trends with mordern web page looks, HD Graphics, Logos and many other things. We always try to put in new web designing idea that can make your website catchy and ready to do business.</p>
            </div>

               <div class="col-md-5">

                   <img src="<?php echo base_url()?>site_asset/img/pricing/real_web.jpg" style="padding: 20px">
               </div>
               <p style="float: left">Beside this our website are always mobile responsive and are compatible to most of the devices. Moble App splash screen designing service is also provided by us. We go step by step with the clients thinking and imaginations. </p>



               <div class="clearfix"></div>

               <h4>How Semicolon IT do Web designing Solutions?</h4>

               <img src="<?php echo base_url()?>site_asset/img/pricing/designingprocess.png" style="padding: 20px">

               <div class="clearfix"></div>

               <p>SemiColon IT has an experienced team UI and Graphics designing. We first analyze the requirement of the client and then decide the plan of action. If required we provide a prototype of the design to the client for their feedback. If satisfied, we move ahead with prototype to convert into real webpage design. FeedBacks are taken from the client on a regular interval so that we and client remain on the same page regarding the the idea of the project  </p>

               <h4>What Does Semicolon IT requires?</h4>

                   <ul class="">
                       <li>We need have the business idea of the client</li>
                       <li>Need a clear idea of the requirements</li>
                       <li>Need images, logo and contents. (If client is not taking these services from us)</li>
                       <li>Timeframe for completing the work.</li>
                   </ul>





           </div>


            <div class="col-lg-3 col-md-3">
                <div class="space-top-3x visible-sm visible-xs"></div>
                <aside class="sidebar">


                    <section class="widget widget_categories">
                        <h3 class="widget-title">
                            <i class="icon-ribbon"></i>
                            Other Services
                        </h3>
                        <ul>
                            <li><a href="#">Website Development</a></li>
                            <li><a href="#">Web Application Development</a></li>
                            <li><a href="#">Mobile App Development</a></li>
                            <li><a href="#">Digital Marketing</a></li>
                            <li><a href="#">Search Engine Optimization</a></li>
                            <li><a href="#">Content Writing</a></li>
                            <li><a href="#">Hosting</a></li>

                        </ul>
                    </section><!-- .widget.widget_categories -->


                    <section class="widget widget_recent_posts">
                        <h3 class="widget-title">
                            <i class="icon-paper"></i>
                            Click To get Best Pricing plans for your Resquirement
                        </h3>
                        <div class="pricing-plan" style="border: none !important;">
                            <div class="pricing-header">

                                <a href="">
                                    <img src="<?php echo base_url() ?>site_asset/img/pricing.jpg" alt="Pricing">
                                </a>
                            </div>


                        </div>


                    </section>


                    <section class="widget widget_recent_posts">
                        <h3 class="widget-title">
                            <i class="icon-paper"></i>
                           Working Technologies
                        </h3>
                        <ul>
                            <li><a href="#">Website Development</a></li>
                            <li><a href="#">Web Application Development</a></li>
                            <li><a href="#">Mobile App Development</a></li>
                            <li><a href="#">Digital Marketing</a></li>
                            <li><a href="#">Search Engine Optimization</a></li>
                            <li><a href="#">Content Writing</a></li>
                            <li><a href="#">Hosting</a></li>

                        </ul>
                        <!-- .item -->
                    </section><!-- .widget.widget_recent_posts -->

                </aside><!-- .sidebar -->
            </div><!-- .col-lg-3.col-md-4 -->



            <!-- Comments -->

        </div><!-- .col-lg-9.col-md-8 -->

        <!-- Sidebar -->






    </div><!-- .row -->



</div><!-- .container -->

<!-- Scroll To Top Button -->
<a href="#" class="scroll-to-top-btn">
    <i class="icon-arrow-up"></i>
</a><!-- .scroll-to-top-btn -->
