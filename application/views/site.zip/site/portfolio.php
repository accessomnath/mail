<section class="page-title">

</section><!-- .page-title -->

<section class="container">
    <h2 class="block-title text-center">
       Semicolon It's Portfolio
        <small>Our latest works</small>
    </h2>

    <!-- Filters -->
    <div class="text-center padding-top">
        <ul class="nav-filters space-bottom-2x text-center">
            <li class="active"><a href="#" data-filter="*">Show All</a></li>
            <li><a href="#" data-filter=".apps">Apps</a></li>
            <li><a href="#" data-filter=".identity">Identity Design</a></li>
        </ul><!-- .nav-filters -->
    </div>

    <!-- Portfolio Grid -->
    <div class="grid isotope-grid no-gap col-3 filter-grid">
        <div class="grid-sizer"></div>
        <div class="gutter-sizer"></div>

        <!-- Portfolio Item -->
        <div class="grid-item apps">
            <a href="#" class="portfolio-item">
                <div class="thumbnail waves-effect waves-light">
                    <img src="<?php echo base_url() ?>site_asset/img/portfolio/01.jpg" alt="Portfolio">
                    <h3 class="portfolio-title">Mobile App</h3>
                </div>
            </a>
        </div><!-- .grid-item.apps -->

        <!-- Portfolio Item -->
        <div class="grid-item identity">
            <a href="#" class="portfolio-item">
                <div class="thumbnail waves-effect waves-light">
                    <img src="<?php echo base_url() ?>site_asset/img/portfolio/02.jpg" alt="Portfolio">
                    <h3 class="portfolio-title">Identity Design</h3>
                </div>
            </a>
        </div><!-- .grid-item.identity -->

        <!-- Portfolio Item -->
        <div class="grid-item identity">
            <a href="#" class="portfolio-item">
                <div class="thumbnail waves-effect waves-light">
                    <img src="<?php echo base_url() ?>site_asset/img/portfolio/03.jpg" alt="Portfolio">
                    <h3 class="portfolio-title">Package Design</h3>
                </div>
            </a>
        </div><!-- .grid-item.identity -->

        <!-- Portfolio Item -->
        <div class="grid-item apps">
            <a href="#" class="portfolio-item">
                <div class="thumbnail waves-effect waves-light">
                    <img src="<?php echo base_url() ?>site_asset/img/portfolio/04.jpg" alt="Portfolio">
                    <h3 class="portfolio-title">App Prototype</h3>
                </div>
            </a>
        </div><!-- .grid-item.apps -->

        <!-- Portfolio Item -->
        <div class="grid-item identity">
            <a href="#" class="portfolio-item">
                <div class="thumbnail waves-effect waves-light">
                    <img src="<?php echo base_url() ?>site_asset/img/portfolio/05.jpg" alt="Portfolio">
                    <h3 class="portfolio-title">Stationery Design</h3>
                </div>
            </a>
        </div><!-- .grid-item.identity -->

        <!-- Portfolio Item -->
        <div class="grid-item apps">
            <a href="#" class="portfolio-item">
                <div class="thumbnail waves-effect waves-light">
                    <img src="<?php echo base_url() ?>site_asset/img/portfolio/06.jpg" alt="Portfolio">
                    <h3 class="portfolio-title">Watch App</h3>
                </div>
            </a>
        </div><!-- .grid-item.apps -->
    </div><!-- .isotope-masonry-grid -->

    <!-- Load More Button -->
    <div class="text-center padding-top">
        <a href="#" class="btn btn-default btn-ghost waves-effect">Load More</a>
    </div>
</section><!-- .container -->
<!-- Scroll To Top Button -->
<a href="#" class="scroll-to-top-btn">
    <i class="icon-arrow-up"></i>
</a><!-- .scroll-to-top-btn -->
