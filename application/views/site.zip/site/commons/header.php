<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SemiColon ITES | Building Enterpises</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="<?php echo base_url()  ?>site_asset/assets/css/bootstrap/bootstrap.min.css">

    <!-- Optional theme -->
    <link rel="stylesheet" href="<?php echo base_url()  ?>site_asset/assets/css/bootstrap/bootstrap-theme.min.css">

    <!-- Custom css -->
    <link rel="stylesheet" href="<?php echo base_url()  ?>site_asset/assets/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url()  ?>site_asset/assets/css/main.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo base_url()  ?>site_asset/assets/css/font-awesome.min.css">

    <link rel="stylesheet" href="<?php echo base_url()  ?>site_asset/assets/css/ionicons.min.css">

    <!-- Flexslider -->
    <link rel="stylesheet" href="<?php echo base_url()  ?>site_asset/assets/css/flexslider.css">

    <!-- Owl -->
    <link rel="stylesheet" href="<?php echo base_url()  ?>site_asset/assets/css/owl.carousel.css">

    <!-- Magnific Popup -->
    <link rel="stylesheet" href="<?php echo base_url()  ?>site_asset/assets/css/magnific-popup.css">

    <link rel="stylesheet" href="<?php echo base_url()  ?>site_asset/assets/css/jquery.fullPage.css">

    <style>

        .do-sevice-section .do-service-container:nth-child(5) .do-front-part {
            background-color: #ff0038;
        }


        .do-sevice-section .do-service-container:nth-child(6) .do-front-part {
            background-color: #04a2ff;
        }

        .do-sevice-section .do-service-container:nth-child(7) .do-front-part {
            background-color: #de03f9;
        }


        .do-sevice-section .do-service-container:nth-child(8) .do-front-part {
            background-color: #fbd000;
        }

        .sdsn-SocialShare {
            float: left;
            width: 100%;
            border-bottom: 1px solid #fff;
        }

        .sdsn-SocialShare ul {
            float: left;
            width: 100%;
            list-style: none;
            margin-bottom: 0;
            display: flex;
            display: -moz-flex;
            display: -webkit-flex;
            align-items: stretch;
            -moz-align-items: stretch;
            -webkit-align-items: stretch;
        }
        .sdsn-SocialShare ul li {
            float: left;
            width: 25%;
        }

        .face {
            background: #3b5998;
        }
        li, ol, ul {
            list-style: none;
            padding-left: 0;
        }
        .twit {
            background: #02a7cb;
        }
        .in {
            background: #0077b5;
        }
        .inst {
            background: #e24a59;
        }

        .sdsn-socialitems {
            float: left;
            width: 100%;
            padding: 60px 50px;
        }

        @media (max-width: 1460px)
        style27.css:1
            .sdsn-socialitems {
                padding: 40px 30px;
            }

            .sdsn-socialImg {
                float: left;
                width: 84px;
                margin-right: 24px;
                top: 0;
                transition: .5s;
                -moz-transition: .5s;
                -webkit-transition: .5s;
            }
            .sdsn-socialdes {
                float: right;
                width: calc(100% - 120px);
            }

            .sdsn-socialImg img {
                width: 82px;
                height: 82px;
            }

            style27.css:1
            img, img:active, img:focus, img:hover {
                outline: 0;
                border: 0;
            }
            .sdsn-socialdes p {
                font-size: 24px;
                margin-bottom: 0;
            }
            .sdsn-socialdes h6, .sdsn-socialdes p {
                width: 100%;
                float: left;
                font-family: carnas-regularuploaded_file;
                color: #fff;
            }
            .sdsn-socialdes h6 {
                font-size: 36px;
            }

            .one-item .image-bg{
                border: 1px solid;
            }


        .one-item{

            padding: 20px;
        }

    </style>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>

<!--  loader  -->
<div id="myloader">
            <span class="loader">
                <img src="<?php echo base_url()  ?>site_asset/assets/img/logo.png" class="normal" alt="logo">
                <img src="<?php echo base_url()  ?>site_asset/assets/img/logo%402x.png" class="retina" alt="logo">
            </span>
</div>

<!--  Main Wrap  -->
<div id="main-wrap">
    <!--  Header & Menu  -->
    <header id="header" class="fixed transparent">
        <nav class="navbar navbar-default white">
            <!--  Header Logo  -->
            <div id="logo">
                <a class="navbar-brand" href="">
                    <img src="<?php echo base_url()  ?>site_asset/assets/img/logo.png" class="normal" alt="logo">
                    <img src="<?php echo base_url()  ?>site_asset/assets/img/logo.png" class="retina" alt="logo">
                    <img src="<?php echo base_url()  ?>site_asset/assets/img/logo.png" class="normal white-logo" alt="logo">
                    <img src="<?php echo base_url()  ?>site_asset/assets/img/logo.png" class="retina white-logo" alt="logo">
                </a>
            </div>
            <!--  END Header Logo  -->
            <!--  Classic menu, responsive menu classic  -->
            <div id="menu-classic">
                <div class="menu-holder">
                    <ul>
                        <li class="submenu">
                            <a href="javascript:void(0)" class="active-item">Home</a>

                        </li>
                        <li class="submenu megasubmenu">
                            <a href="javascript:void(0)">Company <i class="fa fa-bars"></i></a>
                            <!-- mega-lg 4 columns  mega-md 3/2 columns -->
                            <ul class="sub-menu mega-sub-menu mega-md">
                                <li>
                                    <div class="col-lg-6 col-md-6">
                                        <ul>
                                                <span class="header" style="color: white">The Company</span>
                                            <li><a href=""><i class="fa fa-link"></i>About Semicolon ITES</a></li>
                                            <li><a href="#"><i class="fa fa-link"></i>Our Culture & Initiatives </a></li>
                                            <li><a href="#"><i class="fa fa-link"></i>Industries</a></li>
                                        </ul>
                                    </div>
                                    <div class="col-lg-6 col-md-6">
                                        <ul style="margin-top: 33px">
                                            <span class="header"></span>
                                            <li><a href="#" style="margin-top: 20px"><i class="fa fa-link"></i>Why Us?</a></li>
                                            <li><a href="#"><i class="fa fa-link"></i>Blog</a></li>
                                            <li><a href="#"><i class="fa fa-link"></i>Case Studies</a></li>

                                        </ul>
                                    </div>
                                </li>
                            </ul>
                            <!-- END mega-lg 4 columns  mega-md 3/2 columns -->
                        </li>
                        <li class="submenu megasubmenu">
                            <a href="javascript:void(0)">Services <i class="fa fa-bars"></i></a>
                            <!-- mega-lg 4 columns  mega-md 3/2 columns -->
                            <ul class="sub-menu mega-sub-menu mega-md">
                                <li>
                                    <div class="col-lg-6 col-md-6">
                                        <ul>
                                            <span class="header" style="color: white">Our Services</span>

                                            <li><a href="#"><i class="fa fa-link"></i>Web development</a></li>
                                            <li><a href="#"><i class="fa fa-link"></i>Web design</a></li>
                                            <li><a href="#"><i class="fa fa-link"></i>Mobile App development</a></li>
                                        </ul>
                                    </div>
                                    <div class="col-lg-6 col-md-6">
                                        <ul style="margin-top: 33px">
                                            <span class="header"></span>
                                            <li><a href="#" style="margin-top: 20px"><i class="fa fa-link"></i>Graphics Design</a></li>
                                            <li><a href="#"><i class="fa fa-link"></i>Digital marketing</a></li>
                                            <li><a href="#"><i class="fa fa-link"></i>Domain Hostings</a></li>

                                        </ul>
                                    </div>
                                </li>
                            </ul>
                            <!-- END mega-lg 4 columns  mega-md 3/2 columns -->
                        </li>
                        <li class="submenu">
                            <a href="javascript:void(0)">Portfolio</a>

                        </li>
                        <li>
                            <a href="#">Pricing</a>
                        </li>

                        <li>
                            <a href="#">Blog</a>
                        </li>
                        <li class="submenu">
                            <a href="javascript:void(0)">Contacts</a>

                        </li>
                        <!-- Search Icon -->
<!--                        <li class="search">-->
<!--                            <i class="icon ion-ios-search"></i>-->
<!--                        </li>-->
                    </ul>
                </div>
            </div>
            <!--  END Classic menu, responsive menu classic  -->
            <!--  Button for Responsive Menu Classic  -->
            <div id="menu-responsive-classic">
                <div class="menu-button">
                    <span class="bar bar-1"></span>
                    <span class="bar bar-2"></span>
                    <span class="bar bar-3"></span>
                </div>
            </div>
            <!--  END Button for Responsive Menu Classic  -->
            <!--  Search Box  -->
            <div id="search-box">
                <form role="search" id="search-form" class="black big">
                    <div class="form-input">
                        <input class="form-field black big" type="search" placeholder="Search...">
                        <span class="form-button big">
                                    <button type="button">
                                        <i class="icon ion-ios-search"></i>
                                    </button>
                                </span>
                    </div>
                </form>
                <button class="close-search-box">
                    <i class="icon ion-ios-close-empty"></i>
                </button>
            </div>
            <!--  END Search Box  -->
        </nav>
    </header>