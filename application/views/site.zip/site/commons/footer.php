<!--  Footer. Class fixed for fixed footer  -->
<footer class="fixed">
    <div class="row">
        <div class="col-md-4">
            <div class="logo" >
                <h4 style="color: white">Semicolon ITES</h4>

            </div>
            <p class="grey-light">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quia iusto libero ad facere dolores, dignissimos, ducimus incidunt eum odit odio suscipit quas a atque temporibus.</p>
        </div>
        <div class="col-md-2">
            <h6 class="heading white margin-bottom-extrasmall">Useful Links</h6>
            <ul class="sitemap">
                <li><a href="#">Home</a></li>
                <li><a href="#">About us</a></li>
                <li><a href="#">Services</a></li>
                <li><a href="#">Blog</a></li>
                <li><a href="#">Portfolio</a></li>
                <li><a href="#">Contacts</a></li>
            </ul>
        </div>
        <div class="col-md-2">
            <h6 class="heading white margin-bottom-extrasmall">Social</h6>
            <ul class="info">
                <li><a href="#">Facebook</a></li>
                <li><a href="#">Linkedin</a></li>
                <li><a href="#">Instagram</a></li>
                <li><a href="#">Twitter</a></li>
            </ul>
        </div>
        <div class="col-md-4">
            <h6 class="heading white margin-bottom-extrasmall">Contact Us</h6>
            <ul class="info">
                <li>Phone:  <a href="#">+91 096738 79759</a></li>
                <li>Mail:  <a href="#">business@semicolonites.com</a></li>
                <li>Monday to Friday <span class="white">9.00 am to 8.00 pm</span><br>Saturday from <span class="white">9.00 am to 12.00 pm</span></li>
                <li><a href="#">322 Moon St, Venice<br>
                        Italy, 1231</a></li>
            </ul>
        </div>
    </div>
    <div class="copy col-md-12 padding-leftright-null">
        &copy; 2017 <a href="#">Semicolon ITES</a> - Web Desining & Development Company.
        <a href="#main-wrap" class="anchor" id="backtotop">Back to top</a>
    </div>
</footer>
<!--  END Footer. Class fixed for fixed footer  -->
</div>
<!--  Main Wrap  -->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo base_url()  ?>site_asset/assets/js/jquery.min.js"></script>
<!-- All js library -->
<script src="<?php echo base_url()  ?>site_asset/assets/js/bootstrap/bootstrap.min.js"></script>
<script src="<?php echo base_url()  ?>site_asset/assets/js/jquery.flexslider-min.js"></script>
<script src="<?php echo base_url()  ?>site_asset/assets/js/jquery.fullPage.min.js"></script>
<script src="<?php echo base_url()  ?>site_asset/assets/js/owl.carousel.min.js"></script>
<script src="<?php echo base_url()  ?>site_asset/assets/js/isotope.min.js"></script>
<script src="<?php echo base_url()  ?>site_asset/assets/js/jquery.magnific-popup.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;signed_in=false"></script>
<script src="<?php echo base_url()  ?>site_asset/assets/js/jquery.scrollTo.min.js"></script>
<script src="<?php echo base_url()  ?>site_asset/assets/js/smooth.scroll.min.js"></script>
<script src="<?php echo base_url()  ?>site_asset/assets/js/jquery.appear.js"></script>
<script src="<?php echo base_url()  ?>site_asset/assets/js/jquery.countTo.js"></script>
<script src="<?php echo base_url()  ?>site_asset/assets/js/jquery.scrolly.js"></script>
<script src="<?php echo base_url()  ?>site_asset/assets/js/plugins-scroll.js"></script>
<script src="<?php echo base_url()  ?>site_asset/assets/js/imagesloaded.min.js"></script>
<script src="<?php echo base_url()  ?>site_asset/assets/js/pace.min.js"></script>
<script src="<?php echo base_url()  ?>site_asset/assets/js/typed.js"></script>
<script src="<?php echo base_url()  ?>site_asset/assets/js/main.js"></script>
</body>

</html>