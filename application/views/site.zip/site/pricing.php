<section class="page-title">

</section><!-- .page-title -->



<!-- Pricings -->
<section class="fw-section border-bottom padding-top-3x padding-bottom-2x">
    <div class="container">
        <h2 class="block-title text-center">
           Various Service Plans available
            <small>Choose the right pricng plan that may help you to cover up all your requirement. You can also contact us for negotiation and detailed information about pricing and payment.</small>
        </h2>
        <div class="row padding-top">
            <!-- Plan -->
            <div class="col-sm-4">
                <div class="pricing-plan">
                    <div class="pricing-header">
                        <div class="pricing-icon">
                            <img src="img/features/03.png" alt="Pricing">
                        </div>
                        <h3 class="pricing-title">Web Hosting</h3>
                        <p>The ultimate shared hosting solutions!</p>
                        <a href="#" class="btn btn-default btn-icon-right waves-effect waves-light">
                            $3.95/mo
                            <i class="icon-arrow-right"></i>
                        </a>
                    </div>
                    <ul>
                        <li>Domains <strong>1</strong></li>
                        <li>Storage Space <strong>2 GB</strong></li>
                        <li>Subdomains <strong>2</strong></li>
                    </ul>
                </div>
            </div>
            <!-- Plan -->
            <div class="col-sm-4">
                <div class="pricing-plan">
                    <div class="pricing-header">
                        <div class="pricing-icon">
                            <img src="img/features/01.png" alt="Pricing">
                        </div>
                        <h3 class="pricing-title">Cloud Hosting</h3>
                        <p>High performance cloud platform!</p>
                        <a href="#" class="btn btn-primary btn-icon-right waves-effect waves-light">
                            $60.95/mo
                            <i class="icon-arrow-right"></i>
                        </a>
                    </div>
                    <ul>
                        <li>Domains <strong>3</strong></li>
                        <li>Storage Space <strong>100 GB</strong></li>
                        <li>Subdomains <strong>5</strong></li>
                    </ul>
                </div>
            </div>
            <!-- Plan -->
            <div class="col-sm-4">
                <div class="pricing-plan">
                    <div class="pricing-header">
                        <div class="pricing-icon">
                            <img src="img/features/02.png" alt="Pricing">
                        </div>
                        <h3 class="pricing-title">Dedicated Hosting</h3>
                        <p>The ultimate shared hosting solutions!</p>
                        <a href="#" class="btn btn-default btn-icon-right waves-effect waves-light">
                            $200.95/mo
                            <i class="icon-arrow-right"></i>
                        </a>
                    </div>
                    <ul>
                        <li>Domains <strong>10</strong></li>
                        <li>Storage Space <strong>200 GB</strong></li>
                        <li>Subdomains <strong>20</strong></li>
                    </ul>
                </div>
            </div>
        </div><!-- .row -->
    </div><!-- .container -->
</section><!-- .fw-section.border-bottom -->



<!-- CTA -->
<section class="fw-section next-to-footer padding-top-3x padding-bottom-3x" style="background-image: url(<?php echo base_url() ?>/site_asset/img/pricing/cta-bg.jpg); margin-bottom: 0px" >
    <div class="container padding-top text-center">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <h2 class="block-title text-light">
                    Get $10 Credit to launch Own Server
                    <small>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt<br> ut labore et dolore magna aliqua.</small>
                </h2>
            </div>
        </div><!-- .row -->
        <div class="row">
            <div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
                <a href="#" class="btn btn-3d btn-primary btn-block">Enter Promo Code CM2015</a>
                <p class="text-sm text-muted text-uppercase">Promo Expires on 02 / 12 / 16</p>
            </div>
        </div><!-- .row -->
    </div><!-- .container -->
</section>

<div class="clearfix" style="clear: both"></div>

<!-- Scroll To Top Button -->
<a href="#" class="scroll-to-top-btn">
    <i class="icon-arrow-up"></i>
</a><!-- .scroll-to-top-btn -->