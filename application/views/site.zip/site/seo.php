<section class="page-title">

</section><!-- .page-title -->

<!-- Container -->
<div class="container">
    <div class="row">

        <!-- Content -->
        <div class="col-lg-12 col-md-12">
            <h3 align="center">Search Engine Optimization/Marketing & Digital Marketing</h3>

            <div class="image-carousel space-bottom-2x">
                <div class="inner">
                    <img src="<?php echo base_url() ?>site_asset/img/pricing/SEO.jpg" alt="Image">

                </div>
            </div><!-- .image-carousel -->


            <div class="col-md-9 col-lg-9">
                <h4>What is SEO and SEM?</h4>

                <div class="row">
                    <div class="col-md-12">
                        <h5 class="green">Search Engine Optimization</h5>
                        <div class="col-md-7">

                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                        </div>
                        <div class="col-md-5">
                        <img src="<?php echo base_url()?>site_asset/img/seo1.png">
                        </div>
                   </div>
               </div>


                <div class="row">
                    <div class="col-md-12">
                        <h5 class="green">Search Engine Marketing</h5>
                        <div class="col-md-5">
                            <img src="<?php echo base_url()?>site_asset/img/sem.png">
                        </div>
                        <div class="col-md-7">

                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                        </div>

                    </div>
                </div>






            </div>


            <div class="col-lg-3 col-md-3">
                <div class="space-top-3x visible-sm visible-xs"></div>
                <aside class="sidebar">


                    <section class="widget widget_categories">
                        <h3 class="widget-title">
                            <i class="icon-ribbon"></i>
                            Other Services
                        </h3>
                        <ul>
                            <li><a href="#">Website Development</a></li>
                            <li><a href="#">Web App Development</a></li>
                            <li><a href="#">Mobile App Development</a></li>
                            <li><a href="#">Digital Marketing</a></li>
                            <li><a href="#">SEO / SEM</a></li>
                            <li><a href="#">Content Writing</a></li>
                            <li><a href="#">Hosting</a></li>

                        </ul>
                    </section><!-- .widget.widget_categories -->


                    <section class="widget widget_recent_posts">
                        <h3 class="widget-title">
                            <i class="icon-paper"></i>
                            Click To get Best Pricing plans for your Resquirement
                        </h3>
                        <div class="pricing-plan" style="border: none !important;">
                            <div class="pricing-header">

                                <a href="">
                                    <img src="<?php echo base_url() ?>site_asset/img/pricing.jpg" alt="Pricing">
                                </a>
                            </div>


                        </div>


                    </section>


                    <section class="widget widget_recent_posts">
                        <h3 class="widget-title">
                            <i class="icon-paper"></i>
                            Working Technologies
                        </h3>
                        <ul>
                            <li><a href="#">Website Development</a></li>
                            <li><a href="#">Web Application Development</a></li>
                            <li><a href="#">Mobile App Development</a></li>
                            <li><a href="#">Digital Marketing</a></li>
                            <li><a href="#">Search Engine Optimization</a></li>
                            <li><a href="#">Content Writing</a></li>
                            <li><a href="#">Hosting</a></li>

                        </ul>
                        <!-- .item -->
                    </section><!-- .widget.widget_recent_posts -->

                </aside><!-- .sidebar -->
            </div><!-- .col-lg-3.col-md-4 -->



            <!-- Comments -->

        </div><!-- .col-lg-9.col-md-8 -->

        <!-- Sidebar -->






    </div><!-- .row -->



</div><!-- .container -->

<!-- Scroll To Top Button -->
<a href="#" class="scroll-to-top-btn">
    <i class="icon-arrow-up"></i>
</a><!-- .scroll-to-top-btn -->
